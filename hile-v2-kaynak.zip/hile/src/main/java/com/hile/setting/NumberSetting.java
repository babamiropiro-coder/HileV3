package com.hile.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

public class NumberSetting extends Setting {
    private double value;
    private final double min, max, step;

    public NumberSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        set(value);
    }

    public double get() { return value; }
    public float getFloat() { return (float) value; }
    public int getInt() { return (int) Math.round(value); }
    public double getMin() { return min; }
    public double getMax() { return max; }

    public void set(double v) {
        v = Math.round(v / step) * step;
        v = Math.round(v * 10000.0) / 10000.0;
        value = Math.max(min, Math.min(max, v));
    }

    public String display() {
        if (step >= 1.0) return String.valueOf(getInt());
        return String.format(Locale.ROOT, "%.1f", value);
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) {
        if (e != null && e.isJsonPrimitive()) set(e.getAsDouble());
    }
}
