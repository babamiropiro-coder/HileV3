package com.hile.gui;

import com.hile.Config;
import com.hile.module.ModuleManager;
import com.hile.module.impl.Interface;
import com.hile.util.ColorUtil;
import com.hile.util.Render2D;
import com.hile.util.SoundFx;
import com.hile.util.Theme;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.SharedConstants;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerWarningScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

/** Zeno Client main menu (replaces the vanilla title screen). */
public class ZenoTitleScreen extends Screen {
    private static final int[] DOTS = {0xFF3B82F6, 0xFFA855F7, 0xFFFF4D6D};
    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Accounts", "Settings", "Quit"};
    private static final int BW = 124, BH = 20, GAP = 4;

    private final long start = System.nanoTime();
    private long last = start;
    private final float[] hover = new float[LABELS.length];
    private int bx, by0, titleY;

    public ZenoTitleScreen() {
        super(Text.literal("Zeno Client"));
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    protected void init() {
        bx = width - BW - Math.max(24, width / 9);
        int blockH = 46 + LABELS.length * (BH + GAP);
        titleY = Math.max(6, (height - blockH) / 2);
        by0 = titleY + 46;
    }

    private void gradientText(DrawContext ctx, String text, float centerX, float y, float scale, int c1, int c2) {
        TextRenderer tr = textRenderer;
        var m = ctx.getMatrices();
        m.push();
        m.translate(centerX, y, 0f);
        m.scale(scale, scale, 1f);
        int x = -tr.getWidth(text) / 2;
        for (int i = 0; i < text.length(); i++) {
            String ch = text.substring(i, i + 1);
            float t = text.length() <= 1 ? 0f : i / (float) (text.length() - 1);
            ctx.drawText(tr, ch, x, 0, ColorUtil.mix(c1, c2, t), true);
            x += tr.getWidth(ch);
        }
        m.pop();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime();
        float t = (now - start) / 1_000_000_000f;
        float dt = Math.min(0.1f, (now - last) / 1_000_000_000f);
        last = now;

        int a1 = Theme.accent(0);
        int a2 = Theme.accentLight(40);
        int bg = Theme.bg();

        ctx.fillGradient(0, 0, width, height, ColorUtil.mix(bg, 0xFF000000, 0.55f), ColorUtil.mix(bg, 0xFF1A2A55, 0.25f));
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        Render2D.glow(ctx, width * 0.27f + MathHelper.sin(t * 0.30f) * 22f, height * 0.50f + MathHelper.cos(t * 0.25f) * 14f,
                height * 1.35f, a1 & 0xFFFFFF, 0.34f);
        Render2D.glow(ctx, width * 0.82f + MathHelper.cos(t * 0.20f) * 26f, height * 0.12f, height * 1.0f, a2 & 0xFFFFFF, 0.12f);
        Render2D.glow(ctx, width * 0.60f + MathHelper.sin(t * 0.22f) * 30f, height * 1.0f, height * 0.9f, a1 & 0xFFFFFF, 0.10f);

        float size = Math.min(height * 0.64f, width * 0.42f);
        float lx = width * 0.27f - size / 2f;
        float ly = height * 0.5f - size / 2f + MathHelper.sin(t * 1.1f) * 3f;
        float pulse = 0.90f + 0.10f * MathHelper.sin(t * 1.5f);
        Render2D.logo(ctx, (int) lx, (int) ly, (int) size, pulse);

        float cx = bx + BW / 2f;
        gradientText(ctx, "ZENO", cx, titleY, 2.2f, a2, a1);
        gradientText(ctx, "CLIENT", cx, titleY + 22, 1.6f, a2, a1);

        for (int i = 0; i < LABELS.length; i++) {
            int y = by0 + i * (BH + GAP);
            boolean hov = mx >= bx && mx < bx + BW && my >= y && my < y + BH;
            hover[i] += ((hov ? 1f : 0f) - hover[i]) * Math.min(1f, dt * 14f);

            Render2D.round(ctx, bx, y, BW, BH, 5, 0xB0121620);
            Render2D.ring(ctx, bx, y, BW, BH, 5, Theme.alpha(a1, 40 + (int) (110 * hover[i])));
            if (hover[i] > 0.02f) {
                Render2D.round(ctx, bx, y, BW, BH, 5, Theme.alpha(a1, (int) (70 * hover[i])));
                Render2D.round(ctx, bx + 2, y + 5, 2, BH - 10, 1, Theme.alpha(a1, (int) (255 * hover[i])));
            }

            String label = LABELS[i];
            if (i == 2 && client != null) {
                String name = client.getSession().getUsername();
                label = name.length() > 14 ? name.substring(0, 14) : name;
            }
            ctx.drawText(textRenderer, label, bx + (BW - textRenderer.getWidth(label)) / 2, y + 6,
                    hov ? 0xFFFFFFFF : 0xFFB8BCC8, true);
        }

        for (int i = 0; i < DOTS.length; i++) {
            int dx = width - 16 - (DOTS.length - 1 - i) * 14;
            int dy = height - 16;
            Interface ui = ModuleManager.get(Interface.class);
            boolean sel = ui != null && ui.accentIndex() == i;
            Render2D.round(ctx, dx - 1, dy - 1, 10, 10, 5, sel ? 0xFFFFFFFF : 0x40FFFFFF);
            Render2D.round(ctx, dx, dy, 8, 8, 4, DOTS[i]);
        }

        String version = "Minecraft " + SharedConstants.getGameVersion().getName();
        ctx.drawText(textRenderer, version, 6, height - 12, 0xFF6B7285, false);
        String copy = "Copyright \u00A9 ZenoClient 2026";
        ctx.drawText(textRenderer, copy, (width - textRenderer.getWidth(copy)) / 2, height - 12, 0xFF6B7285, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);

        for (int i = 0; i < DOTS.length; i++) {
            int dx = width - 16 - (DOTS.length - 1 - i) * 14;
            int dy = height - 16;
            if (mx >= dx - 3 && mx < dx + 11 && my >= dy - 3 && my < dy + 11) {
                Interface ui = ModuleManager.get(Interface.class);
                if (ui != null) {
                    ui.setAccentIndex(i);
                    Config.save();
                }
                SoundFx.play("ui.button.click", 1.3f, 0.6f);
                return true;
            }
        }

        for (int i = 0; i < LABELS.length; i++) {
            int y = by0 + i * (BH + GAP);
            if (mx >= bx && mx < bx + BW && my >= y && my < y + BH) {
                SoundFx.play("ui.button.click", 1.0f, 0.8f);
                switch (i) {
                    case 0 -> client.setScreen(new SelectWorldScreen(this));
                    case 1 -> client.setScreen(client.options.skipMultiplayerWarning
                            ? new MultiplayerScreen(this)
                            : new MultiplayerWarningScreen(this));
                    case 3 -> client.setScreen(new OptionsScreen(this, client.options));
                    case 4 -> client.scheduleStop();
                    default -> { /* Accounts: shows the current account name only */ }
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
