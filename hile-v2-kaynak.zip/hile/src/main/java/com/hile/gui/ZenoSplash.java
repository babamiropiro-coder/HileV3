package com.hile.gui;

import com.hile.util.Render2D;
import com.hile.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

/** Drawn over the vanilla loading screen so the Z logo replaces the Mojang logo. */
public final class ZenoSplash {
    private static final long START = System.nanoTime();

    private ZenoSplash() {}

    public static void draw(DrawContext ctx) {
        try {
            int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
            float t = (System.nanoTime() - START) / 1_000_000_000f;
            int accent = Theme.accent(0);

            ctx.fillGradient(0, 0, w, h, 0xFF05070D, 0xFF0B1224);
            Render2D.glow(ctx, w / 2f, h * 0.46f, h * 1.2f, accent & 0xFFFFFF, 0.30f);
            int size = (int) (Math.min(w, h) * 0.46f);
            float pulse = 0.88f + 0.12f * MathHelper.sin(t * 2.2f);
            Render2D.logo(ctx, w / 2 - size / 2, (int) (h * 0.44f - size / 2f), size, pulse);

            int bw = Math.min(140, w / 3), bx = w / 2 - bw / 2, by = (int) (h * 0.44f + size / 2f + 14);
            Render2D.round(ctx, bx, by, bw, 4, 2, 0x30FFFFFF);
            float p = (t * 0.45f) % 1f;
            int seg = bw / 3;
            int sx = bx + (int) ((bw - seg) * p);
            Render2D.round(ctx, sx, by, seg, 4, 2, accent);
        } catch (Throwable ignored) {
        }
    }
}
