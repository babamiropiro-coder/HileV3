package com.hile.gui;

import com.hile.Config;
import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.module.impl.Interface;
import com.hile.setting.BoolSetting;
import com.hile.setting.ColorSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.setting.Setting;
import com.hile.util.ColorUtil;
import com.hile.util.Render2D;
import com.hile.util.Theme;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Zeno click menu: sidebar, search, module cards, settings panel, profiles and theme editor. */
public class ClickGuiScreen extends Screen {
    // design space (everything below is laid out in these units and scaled to the screen)
    private static final float DW = 1820f, DH = 965f;
    private static final float SB = 340f;
    private static final float CX = SB + 44f, LW = 640f, RX = CX + LW + 36f, RW = DW - 44f - RX;
    private static final float TOP = 138f, BOTTOM = DH - 26f;

    private enum Page {
        COMBAT("Combat", "combat", Category.COMBAT),
        MOVEMENT("Movement", "movement", Category.MOVEMENT),
        VISUALS("Visuals", "visuals", Category.RENDER),
        COSMETICS("Cosmetics", "cosmetics", Category.COSMETICS),
        CLIENT("Client", "client", Category.CLIENT),
        PRESETS("Presets", "presets", null),
        THEME("Theme", "theme", null);

        final String label;
        final Identifier icon;
        final Category cat;

        Page(String label, String icon, Category cat) {
            this.label = label;
            this.icon = Identifier.of("hile", "textures/gui/icon_" + icon + ".png");
            this.cat = cat;
        }
    }

    private interface Click { void run(int button); }
    private interface Slider { void set(float pct); }
    private record Zone(float x1, float y1, float x2, float y2, int region, Click click, Slider slider, float sx, float sw) {}

    private static Page page = Page.COMBAT;
    private static Module selected;
    private static String selectedProfile;
    private static final Map<Object, Float> ANIM = new HashMap<>();
    private static final Set<ColorSetting> OPEN_COLORS = new HashSet<>();

    private final List<Zone> zones = new ArrayList<>();
    private final long openTime = System.nanoTime();
    private long lastFrame = System.nanoTime();
    private float alpha, step;
    private boolean opened;

    private float scrollL, scrollLT, scrollR, scrollRT, maxL, maxR;
    private float lastS = 1f, lastWx, lastWy;

    private String search = "";
    private boolean searchFocus;
    private Module binding;
    private String status = "";
    private long statusTime;

    private Zone pressZone;
    private int pressButton;
    private Zone sliderZone;
    private int scrollRegion;
    private boolean dragged;
    private double downX, downY;

    public ClickGuiScreen() {
        super(Text.literal("Zeno"));
    }

    @Override
    protected void init() {
        if (!opened) {
            opened = true;
            Interface.playOpen();
        }
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        Config.save();
        Interface.playClose();
    }

    // ------------------------------------------------------------ small helpers

    private int c(int argb) {
        int a = (int) (((argb >>> 24) & 255) * alpha);
        return (a << 24) | (argb & 0xFFFFFF);
    }

    private void rect(DrawContext ctx, float x, float y, float w, float h, float r, int argb) {
        Render2D.round(ctx, Math.round(x), Math.round(y), Math.round(w), Math.round(h), Math.round(r), c(argb));
    }

    private void ring(DrawContext ctx, float x, float y, float w, float h, float r, int argb) {
        Render2D.ring(ctx, Math.round(x), Math.round(y), Math.round(w), Math.round(h), Math.round(r), c(argb));
    }

    private void fill(DrawContext ctx, float x1, float y1, float x2, float y2, int argb) {
        ctx.fill(Math.round(x1), Math.round(y1), Math.round(x2), Math.round(y2), c(argb));
    }

    private void txt(DrawContext ctx, String s, float x, float y, float size, int argb, int align) {
        Render2D.text(ctx, textRenderer, s, x, y, size, c(argb), align);
    }

    private float tw(String s, float size) { return Render2D.textWidth(textRenderer, s, size); }

    private float anim(Object key, float target) {
        float v = ANIM.getOrDefault(key, target);
        v += (target - v) * step;
        if (Math.abs(target - v) < 0.003f) v = target;
        ANIM.put(key, v);
        return v;
    }

    private void icon(DrawContext ctx, Identifier id, float x, float y, float size, int argb) {
        int col = c(argb);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        ctx.setShaderColor(((col >> 16) & 255) / 255f, ((col >> 8) & 255) / 255f, (col & 255) / 255f, ((col >>> 24) & 255) / 255f);
        ctx.drawTexture(id, Math.round(x), Math.round(y), Math.round(size), Math.round(size), 0, 0, 64, 64, 64, 64);
        ctx.setShaderColor(1f, 1f, 1f, 1f);
    }

    private float scale() {
        Interface ui = ModuleManager.get(Interface.class);
        float user = ui == null ? 1f : MathHelper.clamp(ui.menuScale(), 0.6f, 1.4f);
        float fit = Math.min(width * 0.96f / DW, height * 0.94f / DH);
        return Math.min(fit * user, Math.min(width / DW, height / DH));
    }

    private void say(String s) {
        status = s;
        statusTime = System.currentTimeMillis();
    }

    private void zone(float x1, float y1, float x2, float y2, int region, Click click) {
        if (region != 0 && (y2 < TOP || y1 > BOTTOM)) return;
        zones.add(new Zone(x1, y1, x2, y2, region, click, null, 0f, 0f));
    }

    private void sliderZone(float x1, float y1, float x2, float y2, int region, float sx, float sw, Slider s) {
        if (region != 0 && (y2 < TOP || y1 > BOTTOM)) return;
        zones.add(new Zone(x1, y1, x2, y2, region, null, s, sx, sw));
    }

    private List<Module> currentList() {
        List<Module> out = new ArrayList<>();
        if (!search.isEmpty()) {
            String q = search.toLowerCase(Locale.ROOT);
            for (Module m : ModuleManager.getModules()) if (m.getName().toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        } else if (page.cat != null) {
            out.addAll(ModuleManager.byCategory(page.cat));
        }
        return out;
    }

    private Module selectedModule(List<Module> list) {
        if (list.isEmpty()) return null;
        if (selected == null || !list.contains(selected)) selected = list.get(0);
        return selected;
    }

    // ------------------------------------------------------------ render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastFrame) / 1_000_000_000f);
        lastFrame = now;
        float t = Math.min(1f, (now - openTime) / 220_000_000f);
        alpha = 1f - (1f - t) * (1f - t);
        step = Math.min(1f, dt * 16f);

        scrollL += (scrollLT - scrollL) * Math.min(1f, dt * 18f);
        scrollR += (scrollRT - scrollR) * Math.min(1f, dt * 18f);
        zones.clear();

        float s = scale();
        float wx = (width - DW * s) / 2f, wy = (height - DH * s) / 2f;
        lastS = s;
        lastWx = wx;
        lastWy = wy;

        ctx.fill(0, 0, width, height, c(0x99000000));
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        var m = ctx.getMatrices();
        m.push();
        m.translate(wx, wy, 0f);
        m.scale(s, s, 1f);
        drawWindow(ctx);
        m.pop();
    }

    private void drawWindow(DrawContext ctx) {
        int accent = Theme.accent(0);
        int accentL = Theme.accentLight(0);
        int bg = Theme.bg();

        rect(ctx, -10, 10, DW + 20, DH + 20, 40, 0x55000000);
        rect(ctx, 0, 0, DW, DH, 32, bg);

        // ---- sidebar
        rect(ctx, 0, 0, SB, DH, 32, Theme.sidebar());
        fill(ctx, SB - 40, 0, SB, DH, Theme.sidebar());
        fill(ctx, SB, 30, SB + 2, DH - 30, 0x12FFFFFF);
        Render2D.logo(ctx, (int) (SB / 2 - 88), 22, 176, alpha);

        txt(ctx, "FEATURES", 46, 236, 21, Theme.text3(), 0);
        float y = 268;
        Page[] pages = Page.values();
        for (int i = 0; i < 5; i++) {
            navItem(ctx, pages[i], y);
            y += 76;
        }
        txt(ctx, "MANAGER", 46, y + 22, 21, Theme.text3(), 0);
        y += 56;
        for (int i = 5; i < pages.length; i++) {
            navItem(ctx, pages[i], y);
            y += 76;
        }
        fill(ctx, 32, DH - 84, SB - 32, DH - 83, 0x14FFFFFF);
        rect(ctx, 48, DH - 52, 14, 14, 7, accentL);
        txt(ctx, "v2.1.0  -  Fabric 1.21.1", 80, DH - 45, 21, Theme.text3(), 0);

        // ---- content
        List<Module> list = currentList();
        if (!search.isEmpty() || page.cat != null) {
            Module sel = selectedModule(list);
            maxL = 0;
            float endY = drawModuleList(ctx, list);
            maxL = Math.max(0f, endY + scrollL - (BOTTOM - 6f));
            drawModulePanel(ctx, sel);
        } else if (page == Page.PRESETS) {
            drawPresets(ctx);
        } else {
            drawTheme(ctx);
        }
        scrollLT = MathHelper.clamp(scrollLT, 0f, maxL);
        scrollRT = MathHelper.clamp(scrollRT, 0f, maxR);

        // ---- masks hide anything scrolled out of the viewport
        fill(ctx, SB + 2, 0, DW - 32, TOP - 4, bg);
        fill(ctx, SB + 2, BOTTOM, DW - 32, DH - 4, bg);

        // ---- header: search + close
        rect(ctx, CX, 34, DW - 44 - 90 - CX, 70, 22, Theme.field());
        ring(ctx, CX, 34, DW - 44 - 90 - CX, 70, 22, searchFocus ? Theme.alpha(accent, 190) : 0x14FFFFFF);
        icon(ctx, Page.VISUALS.icon, CX + 20, 49, 40, Theme.text3());
        String shown = search.isEmpty() && !searchFocus ? "Search something" : search;
        if (searchFocus && (System.currentTimeMillis() / 500) % 2 == 0) shown += "|";
        txt(ctx, shown, CX + 76, 69, 28, search.isEmpty() && !searchFocus ? Theme.text3() : Theme.text1(), 0);
        zone(CX, 34, DW - 44 - 90, 104, 0, b -> {
            searchFocus = true;
            Interface.playTick();
        });

        float bx = DW - 44 - 70;
        rect(ctx, bx, 34, 70, 70, 22, Theme.field());
        ring(ctx, bx, 34, 70, 70, 22, 0x14FFFFFF);
        txt(ctx, "x", bx + 35, 66, 40, Theme.text1(), 1);
        zone(bx, 34, bx + 70, 104, 0, b -> close());

        ring(ctx, 0, 0, DW, DH, 32, 0x18FFFFFF);
    }

    private void navItem(DrawContext ctx, Page p, float y) {
        boolean sel = page == p && search.isEmpty();
        float a = anim("nav:" + p.name(), sel ? 1f : 0f);
        int accent = Theme.accent(y);
        if (a > 0.01f) {
            Render2D.glow(ctx, 170, y + 33, 260, accent & 0xFFFFFF, 0.14f * a * alpha);
            rect(ctx, 26, y, SB - 52, 66, 20, Theme.alpha(accent, (int) (52 * a)));
            ring(ctx, 26, y, SB - 52, 66, 20, Theme.alpha(accent, (int) (140 * a)));
            rect(ctx, 26, y + 16, 6, 34, 3, Theme.accentLight(y));
        }
        int col = sel ? Theme.accentLight(y) : Theme.text2();
        icon(ctx, p.icon, 66, y + 13, 40, col);
        txt(ctx, p.label, 124, y + 33, 31, sel ? Theme.text1() : Theme.text2(), 0);
        zone(26, y, SB - 26, y + 66, 0, b -> {
            page = p;
            search = "";
            searchFocus = false;
            scrollLT = 0;
            scrollRT = 0;
            scrollL = 0;
            scrollR = 0;
            selected = null;
            Interface.playTick();
        });
    }

    // ------------------------------------------------------------ widgets

    private void toggle(DrawContext ctx, float x, float y, boolean on, Object key) {
        float p = anim(key, on ? 1f : 0f);
        int accent = Theme.accent(y);
        float w = 92, h = 46;
        if (p > 0.02f) Render2D.glow(ctx, x + w / 2, y + h / 2, 150, accent & 0xFFFFFF, 0.28f * p * alpha);
        rect(ctx, x, y, w, h, h / 2, ColorUtil.mix(Theme.field(), accent, p));
        rect(ctx, x + 6 + p * (w - h), y + 6, h - 12, h - 12, (h - 12) / 2, 0xFFFFFFFF);
    }

    private void pill(DrawContext ctx, float x, float y, float w, float h, String label, boolean active, int color) {
        int accent = Theme.accent(y);
        rect(ctx, x, y, w, h, h / 2, active ? Theme.alpha(accent, 60) : Theme.alpha(0xFFFFFF, 10));
        ring(ctx, x, y, w, h, h / 2, active ? Theme.alpha(accent, 170) : 0x1CFFFFFF);
        txt(ctx, label, x + w / 2, y + h / 2, 26, color, 1);
    }

    private void card(DrawContext ctx, float x, float y, float w, float h, String title, String chip) {
        rect(ctx, x, y, w, h, 26, Theme.card());
        ring(ctx, x, y, w, h, 26, 0x0EFFFFFF);
        rect(ctx, x, y, w, 78, 26, Theme.cardHeader());
        fill(ctx, x, y + 40, x + w, y + 78, Theme.cardHeader());
        fill(ctx, x + 2, y + 78, x + w - 2, y + 79, 0x12FFFFFF);
        txt(ctx, title, x + 34, y + 38, 33, Theme.accentLight(y), 0);
        if (chip != null) {
            float cw = Math.max(56, tw(chip, 24) + 28);
            rect(ctx, x + w - 34 - cw, y + 20, cw, 38, 14, Theme.alpha(Theme.accent(y), 44));
            txt(ctx, chip, x + w - 34 - cw / 2, y + 39, 24, Theme.accentLight(y), 1);
        }
    }

    private void hsvSlider(DrawContext ctx, float x, float y, float w, ColorSetting cs, int comp, String label, int region) {
        float[] hsv = ColorUtil.toHsv(cs.get());
        txt(ctx, label, x, y + 20, 24, Theme.text2(), 0);
        float bx = x + 40, bw = w - 40, by = y + 8, bh = 26;
        int segs = 28;
        for (int i = 0; i < segs; i++) {
            float t = i / (float) (segs - 1);
            int col;
            if (comp == 0) col = ColorUtil.fromHsv(t, Math.max(0.55f, hsv[1]), Math.max(0.7f, hsv[2]));
            else if (comp == 1) col = ColorUtil.fromHsv(hsv[0], t, Math.max(0.5f, hsv[2]));
            else col = ColorUtil.fromHsv(hsv[0], hsv[1], t);
            fill(ctx, bx + bw * i / segs, by, bx + bw * (i + 1) / segs + 1, by + bh, 0xFF000000 | col);
        }
        ring(ctx, bx - 2, by - 2, bw + 4, bh + 4, 8, 0x30FFFFFF);
        float kx = bx + bw * hsv[comp];
        rect(ctx, kx - 14, by - 6, 28, bh + 12, 12, 0xFFFFFFFF);
        sliderZone(bx - 10, y, bx + bw + 10, y + 44, region, bx, bw, pct -> {
            float[] h = ColorUtil.toHsv(cs.get());
            h[comp] = MathHelper.clamp(pct, 0f, 1f);
            cs.set(ColorUtil.fromHsv(h[0], h[1], h[2]));
        });
    }

    // ------------------------------------------------------------ module list + settings

    private float drawModuleList(DrawContext ctx, List<Module> list) {
        Map<String, List<Module>> groups = new LinkedHashMap<>();
        if (!search.isEmpty()) groups.put("Results", list);
        else for (Module m : list) groups.computeIfAbsent(m.getGroup(), k -> new ArrayList<>()).add(m);

        float y = TOP - scrollL;
        int accent = Theme.accent(0);
        for (Map.Entry<String, List<Module>> g : groups.entrySet()) {
            List<Module> mods = g.getValue();
            float h = 90 + mods.size() * 92;
            card(ctx, CX, y, LW, h, g.getKey(), String.valueOf(mods.size()));
            float ry = y + 84;
            for (int i = 0; i < mods.size(); i++) {
                Module m = mods.get(i);
                boolean sel = m == selected;
                float a = anim("sel:" + m.getName(), sel ? 1f : 0f);
                if (a > 0.01f) rect(ctx, CX + 12, ry + 6, LW - 24, 80, 18, Theme.alpha(accent, (int) (40 * a)));
                txt(ctx, m.getName(), CX + 34, ry + 44, 31, Theme.text1(), 0);
                for (int d = -1; d <= 1; d++) {
                    rect(ctx, CX + LW - 190 + d * 16 - 4, ry + 42, 8, 8, 4, sel ? Theme.accentLight(ry) : Theme.text3());
                }
                toggle(ctx, CX + LW - 134, ry + 23, m.isEnabled(), m);
                if (i < mods.size() - 1 && !sel && mods.get(i + 1) != selected) {
                    fill(ctx, CX + 28, ry + 92, CX + LW - 28, ry + 93, 0x10FFFFFF);
                }
                zone(CX + 12, ry, CX + LW - 150, ry + 92, 1, b -> {
                    selected = m;
                    scrollRT = 0;
                    scrollR = 0;
                    Interface.playTick();
                });
                zone(CX + LW - 150, ry, CX + LW - 12, ry + 92, 1, b -> m.toggle());
                ry += 92;
            }
            y += h + 28;
        }
        return y;
    }

    private void drawModulePanel(DrawContext ctx, Module m) {
        float h = BOTTOM - TOP;
        rect(ctx, RX, TOP, RW, h, 26, Theme.card());
        ring(ctx, RX, TOP, RW, h, 26, 0x0EFFFFFF);
        if (m == null) {
            txt(ctx, "No module", RX + RW / 2, TOP + 80, 30, Theme.text3(), 1);
            maxR = 0;
            return;
        }

        float cy = TOP + 132 - scrollR;
        for (Setting st : m.getSettings()) cy += drawSetting(ctx, st, RX, cy, RW);

        // keybind row
        txt(ctx, "Bind", RX + 34, cy + 40, 29, Theme.text1(), 0);
        String label = binding == m ? "..." : (m.getKey() == -1 ? "None" : keyName(m.getKey()));
        float bw = Math.max(110, tw(label, 24) + 50);
        rect(ctx, RX + RW - 34 - bw, cy + 16, bw, 48, 14, Theme.alpha(Theme.accent(cy), 44));
        ring(ctx, RX + RW - 34 - bw, cy + 16, bw, 48, 14, Theme.alpha(Theme.accent(cy), 120));
        txt(ctx, label, RX + RW - 34 - bw / 2, cy + 40, 24, Theme.accentLight(cy), 1);
        zone(RX, cy, RX + RW, cy + 80, 2, b -> {
            if (b == 1) m.setKey(-1);
            else binding = m;
            Interface.playTick();
        });
        cy += 80;
        maxR = Math.max(0f, cy + scrollR - (BOTTOM - 16f));

        // fixed header drawn on top of the scrolling content
        rect(ctx, RX, TOP, RW, 112, 26, Theme.cardHeader());
        fill(ctx, RX, TOP + 50, RX + RW, TOP + 112, Theme.cardHeader());
        fill(ctx, RX + 2, TOP + 112, RX + RW - 2, TOP + 113, 0x12FFFFFF);
        txt(ctx, m.getName(), RX + 34, TOP + 38, 34, Theme.text1(), 0);
        String desc = m.getDescription();
        while (tw(desc, 20) > RW - 190 && desc.length() > 4) desc = desc.substring(0, desc.length() - 2);
        if (!desc.equals(m.getDescription())) desc += "..";
        txt(ctx, desc, RX + 34, TOP + 80, 20, Theme.text2(), 0);
        toggle(ctx, RX + RW - 34 - 92, TOP + 33, m.isEnabled(), "head:" + m.getName());
        zone(RX + RW - 140, TOP + 20, RX + RW - 20, TOP + 92, 0, b -> m.toggle());
    }

    private static String keyName(int key) {
        try {
            return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString();
        } catch (Throwable t) {
            return String.valueOf(key);
        }
    }

    private float drawSetting(DrawContext ctx, Setting st, float x, float y, float w) {
        int accent = Theme.accent(y);
        int region = 2;
        if (st instanceof BoolSetting b) {
            txt(ctx, b.getName(), x + 34, y + 40, 29, Theme.text1(), 0);
            toggle(ctx, x + w - 34 - 92, y + 17, b.get(), b);
            zone(x, y, x + w, y + 80, region, k -> {
                b.toggle();
                Interface.playTick();
            });
            return 80;
        }
        if (st instanceof NumberSetting n) {
            txt(ctx, n.getName(), x + 34, y + 28, 29, Theme.text1(), 0);
            txt(ctx, n.display(), x + w - 34, y + 28, 29, Theme.accentLight(y), 2);
            float tx0 = x + 34, tx1 = x + w - 34;
            float pct = (float) ((n.get() - n.getMin()) / (n.getMax() - n.getMin()));
            rect(ctx, tx0, y + 62, tx1 - tx0, 12, 6, Theme.field());
            float fw = Math.max(8, (tx1 - tx0) * pct);
            rect(ctx, tx0, y + 62, fw, 12, 6, accent);
            rect(ctx, tx0 + fw - 14, y + 53, 28, 28, 14, 0xFFFFFFFF);
            sliderZone(x + 14, y + 40, x + w - 14, y + 100, region, tx0, tx1 - tx0, p -> {
                n.set(n.getMin() + MathHelper.clamp(p, 0f, 1f) * (n.getMax() - n.getMin()));
            });
            return 112;
        }
        if (st instanceof ModeSetting md) {
            txt(ctx, md.getName(), x + 34, y + 42, 29, Theme.text1(), 0);
            String v = md.get();
            float pw = Math.max(170, tw(v, 26) + 90);
            float px = x + w - 34 - pw;
            rect(ctx, px, y + 14, pw, 56, 28, Theme.alpha(accent, 44));
            ring(ctx, px, y + 14, pw, 56, 28, Theme.alpha(accent, 120));
            txt(ctx, "<", px + 26, y + 42, 28, Theme.text2(), 1);
            txt(ctx, ">", px + pw - 26, y + 42, 28, Theme.text2(), 1);
            txt(ctx, v, px + pw / 2, y + 42, 26, Theme.accentLight(y), 1);
            zone(px, y + 14, px + pw / 2, y + 70, region, k -> {
                md.cycle(-1);
                Interface.playTick();
            });
            zone(px + pw / 2, y + 14, px + pw, y + 70, region, k -> {
                md.cycle(1);
                Interface.playTick();
            });
            return 84;
        }
        if (st instanceof ColorSetting cs) {
            boolean open = OPEN_COLORS.contains(cs);
            txt(ctx, cs.getName(), x + 34, y + 42, 29, Theme.text1(), 0);
            String hex = String.format("#%06X", cs.get());
            float sw = 60 + tw(hex, 22) + 24;
            rect(ctx, x + w - 34 - sw, y + 14, sw, 56, 16, Theme.field());
            ring(ctx, x + w - 34 - sw, y + 14, sw, 56, 16, 0x24FFFFFF);
            rect(ctx, x + w - 34 - sw + 10, y + 24, 36, 36, 12, cs.argb());
            txt(ctx, hex, x + w - 34 - sw + 56, y + 42, 22, Theme.text2(), 0);
            zone(x, y, x + w, y + 84, region, k -> {
                if (!OPEN_COLORS.remove(cs)) OPEN_COLORS.add(cs);
                Interface.playTick();
            });
            float h = 84;
            if (open) {
                hsvSlider(ctx, x + 34, y + h, w - 68, cs, 0, "H", region);
                hsvSlider(ctx, x + 34, y + h + 58, w - 68, cs, 1, "S", region);
                hsvSlider(ctx, x + 34, y + h + 116, w - 68, cs, 2, "V", region);
                h += 184;
            }
            return h;
        }
        return 0;
    }

    // ------------------------------------------------------------ presets page

    private void drawPresets(DrawContext ctx) {
        List<String> names = Config.list();
        if (selectedProfile == null || !names.contains(selectedProfile)) selectedProfile = Config.active();
        int accent = Theme.accent(0);

        float h = 90 + names.size() * 92;
        float y = TOP - scrollL;
        card(ctx, CX, y, LW, h, "Config Profiles", String.valueOf(names.size()));
        float ry = y + 84;
        for (String n : names) {
            boolean sel = n.equals(selectedProfile);
            float a = anim("prof:" + n, sel ? 1f : 0f);
            if (a > 0.01f) rect(ctx, CX + 12, ry + 6, LW - 24, 80, 18, Theme.alpha(accent, (int) (46 * a)));
            txt(ctx, n, CX + 34, ry + 44, 31, Theme.text1(), 0);
            if (n.equals(Config.active())) {
                rect(ctx, CX + LW - 34 - 120, ry + 24, 120, 44, 22, Theme.alpha(accent, 60));
                txt(ctx, "Active", CX + LW - 34 - 60, ry + 46, 24, Theme.accentLight(ry), 1);
            }
            zone(CX + 12, ry, CX + LW - 12, ry + 92, 1, b -> {
                selectedProfile = n;
                Interface.playTick();
            });
            ry += 92;
        }
        maxL = Math.max(0f, y + h + scrollL - (BOTTOM - 6f));

        // actions panel
        float ph = BOTTOM - TOP;
        card(ctx, RX, TOP, RW, ph, "Actions", null);
        String[] labels = {"Load", "Overwrite", "Save New", "Delete", "Export", "Import"};
        float bw = (RW - 34 * 2 - 24) / 2f, bh = 84;
        for (int i = 0; i < labels.length; i++) {
            float bx = RX + 34 + (i % 2) * (bw + 24);
            float by = TOP + 112 + (i / 2) * (bh + 22);
            rect(ctx, bx, by, bw, bh, 22, Theme.alpha(accent, 46));
            ring(ctx, bx, by, bw, bh, 22, Theme.alpha(accent, 130));
            txt(ctx, labels[i], bx + bw / 2, by + bh / 2, 30, Theme.text1(), 1);
            final int idx = i;
            zone(bx, by, bx + bw, by + bh, 0, b -> presetAction(idx));
        }
        float sy = TOP + 112 + 3 * (bh + 22) + 24;
        txt(ctx, "Selected", RX + 34, sy, 24, Theme.text3(), 0);
        txt(ctx, selectedProfile, RX + RW - 34, sy, 28, Theme.accentLight(sy), 2);
        txt(ctx, "Active", RX + 34, sy + 50, 24, Theme.text3(), 0);
        txt(ctx, Config.active(), RX + RW - 34, sy + 50, 28, Theme.text1(), 2);
        fill(ctx, RX + 28, sy + 86, RX + RW - 28, sy + 87, 0x12FFFFFF);
        if (!status.isEmpty() && System.currentTimeMillis() - statusTime < 6000) {
            txt(ctx, status, RX + 34, sy + 130, 26, Theme.accentLight(sy), 0);
        } else {
            txt(ctx, "Export copies a share code to the clipboard.", RX + 34, sy + 130, 22, Theme.text3(), 0);
            txt(ctx, "Import reads a share code from the clipboard.", RX + 34, sy + 166, 22, Theme.text3(), 0);
        }
    }

    private void presetAction(int idx) {
        String sel = selectedProfile;
        switch (idx) {
            case 0 -> say(sel != null && Config.load(sel) ? "Loaded: " + sel : "Could not load");
            case 1 -> say(sel != null && Config.saveAs(sel) ? "Saved into: " + sel : "Could not save");
            case 2 -> {
                String n = Config.nextName("Profile");
                if (Config.saveAs(n)) {
                    selectedProfile = n;
                    say("Created: " + n);
                } else {
                    say("Could not save");
                }
            }
            case 3 -> {
                if (sel != null && Config.delete(sel)) {
                    say("Deleted: " + sel);
                    selectedProfile = "default";
                } else {
                    say("Cannot delete this profile");
                }
            }
            case 4 -> {
                String ex = sel == null ? null : Config.export(sel);
                if (ex != null && client != null) {
                    client.keyboard.setClipboard(ex);
                    say("Copied to clipboard");
                } else {
                    say("Nothing to export");
                }
            }
            default -> {
                String text = client == null ? null : client.keyboard.getClipboard();
                String n = Config.importString(text);
                if (n != null) {
                    selectedProfile = n;
                    say("Imported as: " + n);
                } else {
                    say("Clipboard has no Zeno config");
                }
            }
        }
        Interface.playTick();
    }

    // ------------------------------------------------------------ theme page

    private void drawTheme(DrawContext ctx) {
        Interface ui = ModuleManager.get(Interface.class);
        if (ui == null) return;
        int accent = Theme.accent(0);
        String[] modes = {"Blue", "Purple", "Crimson", "Green", "Rainbow", "Custom"};

        float y = TOP - scrollL;
        float h = 110 + 2 * 78 + 3 * (84 + 184) + 30;
        card(ctx, CX, y, LW, h, "Colors", null);

        float py = y + 100;
        float pw = (LW - 68 - 2 * 14) / 3f;
        for (int i = 0; i < modes.length; i++) {
            float px = CX + 34 + (i % 3) * (pw + 14);
            float qy = py + (i / 3) * 78;
            final int idx = i;
            boolean on = ui.accentIndex() == i;
            pill(ctx, px, qy, pw, 62, modes[i], on, on ? Theme.text1() : Theme.text2());
            zone(px, qy, px + pw, qy + 62, 1, b -> {
                ui.setAccentIndex(idx);
                Interface.playTick();
            });
        }

        float ey = py + 2 * 78 + 10;
        ColorSetting[] settings = {ui.customAccentSetting(), ui.textColorSetting(), ui.bgColorSetting()};
        for (ColorSetting cs : settings) {
            txt(ctx, cs.getName(), CX + 34, ey + 30, 29, Theme.text1(), 0);
            String hex = String.format("#%06X", cs.get());
            rect(ctx, CX + LW - 34 - 190, ey + 6, 190, 54, 16, Theme.field());
            rect(ctx, CX + LW - 34 - 190 + 10, ey + 15, 36, 36, 12, cs.argb());
            txt(ctx, hex, CX + LW - 34 - 190 + 58, ey + 33, 22, Theme.text2(), 0);
            hsvSlider(ctx, CX + 34, ey + 76, LW - 68, cs, 0, "H", 1);
            hsvSlider(ctx, CX + 34, ey + 136, LW - 68, cs, 1, "S", 1);
            hsvSlider(ctx, CX + 34, ey + 196, LW - 68, cs, 2, "V", 1);
            ey += 268;
        }
        maxL = Math.max(0f, y + h + scrollL - (BOTTOM - 6f));

        // preview panel
        float ph = BOTTOM - TOP;
        card(ctx, RX, TOP, RW, ph, "Preview", null);
        float py2 = TOP + 112;
        rect(ctx, RX + 24, py2, RW - 48, 92, 20, Theme.alpha(accent, 40));
        txt(ctx, "KillAura", RX + 54, py2 + 46, 31, Theme.text1(), 0);
        toggle(ctx, RX + RW - 34 - 92 - 24, py2 + 23, true, "prev:a");
        txt(ctx, "AutoPot", RX + 54, py2 + 138, 31, Theme.text1(), 0);
        toggle(ctx, RX + RW - 34 - 92 - 24, py2 + 115, false, "prev:b");
        txt(ctx, "Range", RX + 54, py2 + 218, 29, Theme.text1(), 0);
        txt(ctx, "3.0", RX + RW - 58, py2 + 218, 29, Theme.accentLight(py2), 2);
        rect(ctx, RX + 54, py2 + 252, RW - 108, 12, 6, Theme.field());
        rect(ctx, RX + 54, py2 + 252, (RW - 108) * 0.55f, 12, 6, accent);
        rect(ctx, RX + 54 + (RW - 108) * 0.55f - 14, py2 + 243, 28, 28, 14, 0xFFFFFFFF);
        txt(ctx, "Secondary text", RX + 54, py2 + 310, 26, Theme.text2(), 0);
        txt(ctx, "Muted text", RX + 54, py2 + 350, 24, Theme.text3(), 0);

        // menu scale + reset
        NumberSetting sc = null;
        for (Setting st : ui.getSettings()) if (st.getName().equals("Menu Scale")) sc = (NumberSetting) st;
        float sy = py2 + 420;
        if (sc != null) {
            final NumberSetting fsc = sc;
            txt(ctx, "Menu Scale", RX + 54, sy, 29, Theme.text1(), 0);
            txt(ctx, fsc.display(), RX + RW - 58, sy, 29, Theme.accentLight(sy), 2);
            float tx0 = RX + 54, tx1 = RX + RW - 54;
            float pct = (float) ((fsc.get() - fsc.getMin()) / (fsc.getMax() - fsc.getMin()));
            rect(ctx, tx0, sy + 34, tx1 - tx0, 12, 6, Theme.field());
            rect(ctx, tx0, sy + 34, Math.max(8, (tx1 - tx0) * pct), 12, 6, accent);
            rect(ctx, tx0 + (tx1 - tx0) * pct - 14, sy + 25, 28, 28, 14, 0xFFFFFFFF);
            sliderZone(RX + 30, sy + 10, RX + RW - 30, sy + 70, 0, tx0, tx1 - tx0, p ->
                    fsc.set(fsc.getMin() + MathHelper.clamp(p, 0f, 1f) * (fsc.getMax() - fsc.getMin())));
        }
        float ry = sy + 96;
        rect(ctx, RX + 34, ry, RW - 68, 76, 22, Theme.alpha(accent, 46));
        ring(ctx, RX + 34, ry, RW - 68, 76, 22, Theme.alpha(accent, 130));
        txt(ctx, "Reset Theme", RX + RW / 2, ry + 38, 30, Theme.text1(), 1);
        zone(RX + 34, ry, RX + RW - 34, ry + 76, 0, b -> {
            ui.resetTheme();
            Interface.playTick();
        });
        maxR = 0;
    }

    // ------------------------------------------------------------ input

    private float toDX(double mx) { return (float) ((mx - lastWx) / lastS); }
    private float toDY(double my) { return (float) ((my - lastWy) / lastS); }

    private boolean inViewport(Zone z, float dy) {
        return z.region() == 0 || (dy >= TOP && dy <= BOTTOM);
    }

    private int regionAt(float dx, float dy) {
        if (dy < TOP || dy > BOTTOM) return 0;
        if (dx >= CX && dx <= CX + LW) return 1;
        if (dx >= RX && dx <= DW - 44) return 2;
        return 0;
    }

    private void applySlider(float dx) {
        if (sliderZone == null || sliderZone.sw() <= 0) return;
        sliderZone.slider().set((dx - sliderZone.sx()) / sliderZone.sw());
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        float dx = toDX(mx), dy = toDY(my);
        searchFocus = false;
        dragged = false;
        downX = mx;
        downY = my;
        pressZone = null;
        sliderZone = null;
        scrollRegion = regionAt(dx, dy);

        for (int i = zones.size() - 1; i >= 0; i--) {
            Zone z = zones.get(i);
            if (dx >= z.x1() && dx < z.x2() && dy >= z.y1() && dy < z.y2() && inViewport(z, dy)) {
                if (z.slider() != null) {
                    sliderZone = z;
                    applySlider(dx);
                } else {
                    pressZone = z;
                    pressButton = button;
                    scrollRegion = z.region() == 0 ? 0 : z.region();
                }
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double ddx, double ddy) {
        if (sliderZone != null) {
            applySlider(toDX(mx));
            return true;
        }
        if (scrollRegion != 0) {
            if (!dragged && Math.hypot(mx - downX, my - downY) > 5.0) {
                dragged = true;
                pressZone = null;
            }
            if (dragged) {
                float d = (float) (ddy / lastS);
                if (scrollRegion == 1) {
                    scrollLT = MathHelper.clamp(scrollLT - d, 0f, maxL);
                    scrollL = scrollLT;
                } else {
                    scrollRT = MathHelper.clamp(scrollRT - d, 0f, maxR);
                    scrollR = scrollRT;
                }
            }
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (pressZone != null && !dragged && pressZone.click() != null) pressZone.click().run(pressButton);
        pressZone = null;
        sliderZone = null;
        scrollRegion = 0;
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        int r = regionAt(toDX(mx), toDY(my));
        float d = (float) (-vertical * 60.0);
        if (r == 1) scrollLT = MathHelper.clamp(scrollLT + d, 0f, maxL);
        else if (r == 2) scrollRT = MathHelper.clamp(scrollRT + d, 0f, maxR);
        return true;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocus && chr >= 32 && chr != 127 && search.length() < 24) {
            search += chr;
            scrollLT = 0;
            scrollL = 0;
            selected = null;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_BACKSPACE) binding.setKey(-1);
            else binding.setKey(keyCode);
            binding = null;
            return true;
        }
        if (searchFocus) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
                search = search.substring(0, search.length() - 1);
                selected = null;
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                searchFocus = false;
                return true;
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
