package com.hile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

/** Named config profiles stored in config/zeno/profiles. The active profile is auto-saved. */
public final class Config {
    private static final Gson PRETTY = new GsonBuilder().setPrettyPrinting().create();
    private static final String PREFIX = "ZENO1:";
    private static String active = "default";

    private Config() {}

    private static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("zeno"); }
    private static Path profileDir() { return dir().resolve("profiles"); }

    public static String safe(String name) {
        String s = name == null ? "" : name.replaceAll("[^A-Za-z0-9 _\\-]", "").trim();
        return s.isEmpty() ? "profile" : (s.length() > 24 ? s.substring(0, 24) : s);
    }

    private static Path file(String name) { return profileDir().resolve(safe(name) + ".json"); }

    public static String active() { return active; }

    // ------------------------------------------------------------ snapshot / apply

    private static JsonObject snapshot() {
        JsonObject root = new JsonObject();
        for (Module m : ModuleManager.getModules()) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            o.addProperty("key", m.getKey());
            JsonObject s = new JsonObject();
            for (Setting st : m.getSettings()) s.add(st.getName(), st.toJson());
            o.add("settings", s);
            root.add(m.getName(), o);
        }
        return root;
    }

    private static void apply(JsonObject root) {
        for (Module m : ModuleManager.getModules()) {
            if (!root.has(m.getName())) continue;
            JsonObject o = root.getAsJsonObject(m.getName());
            if (o.has("key")) m.setKey(o.get("key").getAsInt());
            if (o.has("settings")) {
                JsonObject s = o.getAsJsonObject("settings");
                for (Setting st : m.getSettings()) {
                    if (s.has(st.getName())) st.fromJson(s.get(st.getName()));
                }
            }
            if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean(), false);
        }
    }

    // ------------------------------------------------------------ lifecycle

    public static void init() {
        try {
            Files.createDirectories(profileDir());
            Path marker = dir().resolve("active.txt");
            if (Files.exists(marker)) active = safe(Files.readString(marker).trim());

            if (!Files.exists(file(active))) {
                Path old = FabricLoader.getInstance().getConfigDir().resolve("hile.json");
                if (Files.exists(old)) Files.copy(old, file(active));   // migrate the old single-file config
            }
            if (Files.exists(file(active))) {
                apply(JsonParser.parseString(Files.readString(file(active))).getAsJsonObject());
            }
        } catch (Exception ignored) {
        }
    }

    /** Auto-save into the active profile. */
    public static void save() { saveAs(active); }

    public static boolean saveAs(String name) {
        try {
            Files.createDirectories(profileDir());
            Files.writeString(file(name), PRETTY.toJson(snapshot()));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean load(String name) {
        try {
            if (!Files.exists(file(name))) return false;
            apply(JsonParser.parseString(Files.readString(file(name))).getAsJsonObject());
            active = safe(name);
            Files.writeString(dir().resolve("active.txt"), active);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean delete(String name) {
        try {
            if (safe(name).equals("default")) return false;
            return Files.deleteIfExists(file(name));
        } catch (Exception e) {
            return false;
        }
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(profileDir())) {
            s.forEach(p -> {
                String n = p.getFileName().toString();
                if (n.endsWith(".json")) out.add(n.substring(0, n.length() - 5));
            });
        } catch (Exception ignored) {
        }
        Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        if (!out.contains("default")) out.add(0, "default");
        return out;
    }

    public static String nextName(String base) {
        List<String> existing = list();
        for (int i = 1; i < 1000; i++) {
            String n = base + " " + i;
            if (!existing.contains(n)) return n;
        }
        return base + " X";
    }

    // ------------------------------------------------------------ share via clipboard

    public static String export(String name) {
        try {
            JsonObject o = JsonParser.parseString(Files.readString(file(name))).getAsJsonObject();
            String json = o.toString();
            return PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(json.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            return null;
        }
    }

    /** Returns the new profile name, or null if the text is not a valid config string. */
    public static String importString(String text) {
        try {
            if (text == null) return null;
            String t = text.trim();
            if (!t.startsWith(PREFIX)) return null;
            byte[] raw = Base64.getUrlDecoder().decode(t.substring(PREFIX.length()));
            JsonObject o = JsonParser.parseString(new String(raw, StandardCharsets.UTF_8)).getAsJsonObject();
            String name = nextName("Imported");
            Files.createDirectories(profileDir());
            Files.writeString(file(name), PRETTY.toJson(o));
            return name;
        } catch (Exception e) {
            return null;
        }
    }
}
