package com.hile.cosmetics;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public final class HatModels {
    public static final EntityModelLayer LAYER = new EntityModelLayer(Identifier.of("hile", "hats"), "main");

    public static final EntityModelLayer BACK_LAYER = new EntityModelLayer(Identifier.of("hile", "back"), "main");

    private HatModels() {}

    public static TexturedModelData createBack() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        root.addChild("wing_l", ModelPartBuilder.create()
                .uv(0, 0).cuboid(0f, 0f, 0f, 14f, 2f, 1f)
                .uv(0, 0).cuboid(0f, 2f, 0f, 12f, 2f, 1f)
                .uv(0, 0).cuboid(0f, 4f, 0f, 10f, 2f, 1f)
                .uv(0, 0).cuboid(0f, 6f, 0f, 7f, 2f, 1f),
                ModelTransform.pivot(2f, 1f, 2.5f));
        root.addChild("wing_r", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-14f, 0f, 0f, 14f, 2f, 1f)
                .uv(0, 0).cuboid(-12f, 2f, 0f, 12f, 2f, 1f)
                .uv(0, 0).cuboid(-10f, 4f, 0f, 10f, 2f, 1f)
                .uv(0, 0).cuboid(-7f, 6f, 0f, 7f, 2f, 1f),
                ModelTransform.pivot(-2f, 1f, 2.5f));
        root.addChild("backpack", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, 1f, 2f, 7f, 9f, 4f),
                ModelTransform.NONE);
        return TexturedModelData.of(data, 64, 64);
    }

    public static TexturedModelData create() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();

        // Top hat (texture rows: 0-31 black, 32-41 red band)
        root.addChild("tophat", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-6f, -9.5f, -6f, 12f, 1f, 12f)
                .uv(0, 16).cuboid(-4f, -17.5f, -4f, 8f, 8f, 8f)
                .uv(0, 32).cuboid(-4.5f, -10.5f, -4.5f, 9f, 1f, 9f),
                ModelTransform.NONE);

        // Crown
        root.addChild("crown", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-4.5f, -11f, -4.5f, 9f, 3f, 9f)
                .uv(0, 16).cuboid(-4.5f, -14f, -4.5f, 2f, 3f, 2f)
                .uv(0, 16).cuboid(2.5f, -14f, -4.5f, 2f, 3f, 2f)
                .uv(0, 16).cuboid(-4.5f, -14f, 2.5f, 2f, 3f, 2f)
                .uv(0, 16).cuboid(2.5f, -14f, 2.5f, 2f, 3f, 2f)
                .uv(0, 24).cuboid(-1f, -10.5f, -5f, 2f, 2f, 1f),
                ModelTransform.NONE);

        // Halo (floating ring)
        root.addChild("halo", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-5f, -14f, -5f, 10f, 1f, 1f)
                .uv(0, 0).cuboid(-5f, -14f, 4f, 10f, 1f, 1f)
                .uv(0, 0).cuboid(-5f, -14f, -4f, 1f, 1f, 8f)
                .uv(0, 0).cuboid(4f, -14f, -4f, 1f, 1f, 8f),
                ModelTransform.NONE);

        root.addChild("glasses", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-4f, -5f, -5.1f, 3f, 2f, 1f)
                .uv(0, 0).cuboid(1f, -5f, -5.1f, 3f, 2f, 1f)
                .uv(0, 16).cuboid(-1f, -4.6f, -5.1f, 2f, 1f, 1f)
                .uv(0, 16).cuboid(-4.6f, -4.7f, -5.1f, 1f, 1f, 5f)
                .uv(0, 16).cuboid(3.6f, -4.7f, -5.1f, 1f, 1f, 5f),
                ModelTransform.NONE);

        root.addChild("ears", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-4f, -10f, -1.5f, 2f, 2f, 2f)
                .uv(0, 0).cuboid(2f, -10f, -1.5f, 2f, 2f, 2f)
                .uv(0, 16).cuboid(-3.6f, -9.6f, -1.6f, 1f, 1f, 1f)
                .uv(0, 16).cuboid(2.6f, -9.6f, -1.6f, 1f, 1f, 1f),
                ModelTransform.NONE);

        return TexturedModelData.of(data, 64, 64);
    }
}
