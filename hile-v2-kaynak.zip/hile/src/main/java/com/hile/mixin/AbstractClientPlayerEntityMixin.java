package com.hile.mixin;

import com.hile.module.impl.Cape;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void hile$cape(CallbackInfoReturnable<SkinTextures> cir) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        Identifier cape = Cape.texture();
        if (cape == null) return;
        Identifier elytra = Cape.elytraTexture();
        SkinTextures o = cir.getReturnValue();
        cir.setReturnValue(new SkinTextures(o.texture(), o.textureUrl(), cape,
                elytra != null ? elytra : o.elytraTexture(), o.model(), o.secure()));
    }
}
