package com.hile.mixin;

import com.hile.gui.ZenoTitleScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    /** Swaps the vanilla title screen for the Zeno Client one. */
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen hile$zenoTitle(Screen screen) {
        if (screen != null && screen.getClass() == TitleScreen.class) {
            return new ZenoTitleScreen();
        }
        return screen;
    }
}
