package com.hile.mixin;

import com.hile.module.impl.AutoPot;
import com.hile.module.impl.KillAura;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {
    /** AutoPot retreat: walk forward. KillAura criticals: jump. */
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void hile$input(CallbackInfo ci) {
        if (AutoPot.isRetreating()) {
            this.pressingForward = true;
            this.pressingBack = false;
            this.movementForward = 1.0f;
            this.movementSideways = 0.0f;
        }
        if (KillAura.wantsJump()) {
            this.jumping = true;
        }
    }
}
