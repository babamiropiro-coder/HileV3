package com.hile.util;

import com.hile.module.ModuleManager;
import com.hile.module.impl.Interface;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public final class Theme {
    private static final Identifier Z_BLUE = Identifier.of("hile", "textures/gui/z_blue.png");
    private static final Identifier Z_PURPLE = Identifier.of("hile", "textures/gui/z_purple.png");
    private static final Identifier Z_CRIMSON = Identifier.of("hile", "textures/gui/z_crimson.png");
    private static final Identifier Z_GREEN = Identifier.of("hile", "textures/gui/z_green.png");
    private static final Identifier Z_WHITE = Identifier.of("hile", "textures/gui/z_white.png");

    private Theme() {}

    private static Interface ui() { return ModuleManager.get(Interface.class); }

    private static String mode() {
        Interface u = ui();
        return u == null ? "Blue" : u.accentMode();
    }

    /** Opaque ARGB accent color. offset shifts the rainbow phase. */
    public static int accent(float offset) {
        switch (mode()) {
            case "Purple":  return 0xFFA855F7;
            case "Crimson": return 0xFFFF4D6D;
            case "Green":   return 0xFF4ADE80;
            case "Rainbow": {
                float hue = (((System.currentTimeMillis() / 25.0f) + offset) % 360f) / 360f;
                return MathHelper.hsvToRgb(hue, 0.55f, 1.0f) | 0xFF000000;
            }
            case "Custom":  return 0xFF000000 | ui().customAccent();
            default:        return 0xFF3B82F6;
        }
    }

    public static int accentLight(float offset) { return ColorUtil.mix(accent(offset), 0xFFFFFFFF, 0.35f); }

    public static int text1() { Interface u = ui(); return 0xFF000000 | (u == null ? 0xE9EEFA : u.textColor()); }
    public static int bg() { Interface u = ui(); return 0xFF000000 | (u == null ? 0x0B0E16 : u.bgColor()); }
    public static int text2() { return ColorUtil.mix(text1(), bg(), 0.42f); }
    public static int text3() { return ColorUtil.mix(text1(), bg(), 0.68f); }
    public static int sidebar() { return ColorUtil.mix(bg(), 0xFF000000, 0.25f); }
    public static int card() { return ColorUtil.mix(bg(), 0xFFFFFFFF, 0.05f); }
    public static int cardHeader() { return ColorUtil.mix(bg(), 0xFFFFFFFF, 0.09f); }
    public static int field() { return ColorUtil.mix(bg(), 0xFFFFFFFF, 0.075f); }

    public static Identifier logo() {
        switch (mode()) {
            case "Purple":  return Z_PURPLE;
            case "Crimson": return Z_CRIMSON;
            case "Green":   return Z_GREEN;
            case "Rainbow":
            case "Custom":  return Z_WHITE;
            default:        return Z_BLUE;
        }
    }

    public static boolean logoTinted() {
        String m = mode();
        return m.equals("Rainbow") || m.equals("Custom");
    }

    public static int alpha(int rgb, int a) { return ((a & 0xFF) << 24) | (rgb & 0xFFFFFF); }
}
