package com.hile.util;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.BlockPos;

public final class CritUtil {
    private CritUtil() {}

    public static boolean inWeb(ClientPlayerEntity p) {
        var w = MinecraftClient.getInstance().world;
        if (w == null) return false;
        return w.getBlockState(p.getBlockPos()).isOf(Blocks.COBWEB)
                || w.getBlockState(BlockPos.ofFloored(p.getEyePos())).isOf(Blocks.COBWEB);
    }

    /** A critical hit is physically possible right now (not in water, web, ladder, vehicle...). */
    public static boolean possible(ClientPlayerEntity p) {
        return !p.isTouchingWater() && !p.isClimbing() && !p.hasVehicle()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS) && !inWeb(p);
    }

    /** Falling right now, so the next full-charge hit is a critical hit. */
    public static boolean canCrit(ClientPlayerEntity p) {
        return possible(p) && p.fallDistance > 0.0f && !p.isOnGround();
    }
}
