package com.hile.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;

public final class ItemUtil {
    private ItemUtil() {}

    /**
     * Uses the item in the given hotbar slot, then restores the previous slot.
     * If setLook is true the item is used with the given yaw/pitch and the old look is restored right after.
     */
    public static void use(int slot, float yaw, float pitch, boolean setLook) {
        use(slot, yaw, pitch, setLook, true);
    }

    /** restoreLook=false keeps the camera at the throw angle (visible head movement). */
    public static void use(int slot, float yaw, float pitch, boolean setLook, boolean restoreLook) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        ClientPlayNetworkHandler net = mc.getNetworkHandler();
        if (p == null || net == null || mc.interactionManager == null) return;

        PlayerInventory inv = p.getInventory();
        int prevSlot = inv.selectedSlot;
        float oldYaw = p.getYaw();
        float oldPitch = p.getPitch();

        if (slot != prevSlot) {
            inv.selectedSlot = slot;
            net.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        }
        if (setLook) {
            p.setYaw(yaw);
            p.setPitch(pitch);
            net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround()));
        }

        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);

        if (setLook && restoreLook) {
            p.setYaw(oldYaw);
            p.setPitch(oldPitch);
            net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(oldYaw, oldPitch, p.isOnGround()));
        } else if (setLook) {
            p.prevYaw = yaw;
            p.prevPitch = pitch;
        }
        if (slot != prevSlot) {
            inv.selectedSlot = prevSlot;
            net.sendPacket(new UpdateSelectedSlotC2SPacket(prevSlot));
        }
    }
}
