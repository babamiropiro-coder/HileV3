package com.hile.util;

import net.minecraft.util.math.MathHelper;

public final class ColorUtil {
    private ColorUtil() {}

    public static float[] toHsv(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float d = max - min;
        float h = 0f;
        if (d > 0f) {
            if (max == r) h = ((g - b) / d) % 6f;
            else if (max == g) h = (b - r) / d + 2f;
            else h = (r - g) / d + 4f;
            h /= 6f;
            if (h < 0f) h += 1f;
        }
        float s = max == 0f ? 0f : d / max;
        return new float[]{h, s, max};
    }

    public static int fromHsv(float h, float s, float v) {
        return MathHelper.hsvToRgb(MathHelper.clamp(h, 0f, 1f), MathHelper.clamp(s, 0f, 1f), MathHelper.clamp(v, 0f, 1f)) & 0xFFFFFF;
    }

    /** Opaque mix of two colors. */
    public static int mix(int c1, int c2, float t) {
        int r = (int) MathHelper.lerp(t, (c1 >> 16) & 255, (c2 >> 16) & 255);
        int g = (int) MathHelper.lerp(t, (c1 >> 8) & 255, (c2 >> 8) & 255);
        int b = (int) MathHelper.lerp(t, c1 & 255, c2 & 255);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public static int alpha(int rgb, int a) {
        return ((a & 255) << 24) | (rgb & 0xFFFFFF);
    }
}
