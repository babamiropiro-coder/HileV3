package com.hile.util;

import com.hile.module.impl.AntiBot;
import net.minecraft.entity.player.PlayerEntity;

public final class AntiBotHelper {
    private AntiBotHelper() {}

    public static boolean isBot(PlayerEntity pe) { return AntiBot.isBot(pe); }
}
