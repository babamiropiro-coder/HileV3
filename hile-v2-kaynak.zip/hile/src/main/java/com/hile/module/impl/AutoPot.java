package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.CritUtil;
import com.hile.util.ItemUtil;
import com.hile.util.TargetUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;

public class AutoPot extends Module {
    private static final int HEAL = 1, STRENGTH = 2, SPEED = 3;

    private static volatile boolean retreating;

    private final BoolSetting healthPots = add(new BoolSetting("Health Pots", true));
    private final NumberSetting healthAt = add(new NumberSetting("Health At", 10, 1, 19, 1));
    private final BoolSetting strengthPots = add(new BoolSetting("Strength Pots", true));
    private final BoolSetting speedPots = add(new BoolSetting("Speed Pots", true));
    private final BoolSetting combatOnly = add(new BoolSetting("Buffs Only In Combat", true));
    private final NumberSetting combatRange = add(new NumberSetting("Combat Range", 24, 8, 64, 2));
    private final ModeSetting avoid = add(new ModeSetting("Avoid", "Players", "All Living"));
    private final NumberSetting maxSelf = add(new NumberSetting("Max Self Distance", 2.5, 1.0, 3.5, 0.1));
    private final NumberSetting margin = add(new NumberSetting("Safety Margin", 1.0, 0.0, 3.0, 0.1));
    private final NumberSetting delay = add(new NumberSetting("Delay (ticks)", 8, 2, 40, 1));
    private final BoolSetting retreat = add(new BoolSetting("Retreat", true));
    private final BoolSetting retreatBuffs = add(new BoolSetting("Retreat For Buffs", false));
    private final NumberSetting retreatRange = add(new NumberSetting("Retreat Range", 16, 6, 32, 1));
    private final NumberSetting maxRetreat = add(new NumberSetting("Max Retreat (ticks)", 80, 20, 200, 10));
    private final BoolSetting panic = add(new BoolSetting("Panic Throw", true));
    private final NumberSetting panicHealth = add(new NumberSetting("Panic Health", 6, 1, 19, 1));
    private final NumberSetting panicDelay = add(new NumberSetting("Panic Delay (ticks)", 14, 4, 60, 1));

    private final BoolSetting lookDown = add(new BoolSetting("Look Down To Throw", true));
    private final BoolSetting faceEnemy = add(new BoolSetting("Face Enemy After", true));

    private LivingEntity faceTarget;
    private int faceTicks;
    private int cooldown;
    private int retreatTicks;
    private int pause;
    private int noSafeTicks;
    private int stuckTicks;
    private Vec3d lastPos;
    private float retreatYaw;
    private long last = System.nanoTime();

    private record Landing(Vec3d pos, int ticks, boolean hitEntity) {}

    public AutoPot() {
        super("AutoPot", "Iksirleri rakibe degmeyecek sekilde atar. Sikisinca (ag, cukur) yine de atar.", Category.COMBAT);
        group("Support");
    }

    public static boolean isRetreating() { return retreating; }

    @Override
    protected void onDisable() {
        retreating = false;
        retreatTicks = 0;
        pause = 0;
        noSafeTicks = 0;
        stuckTicks = 0;
    }

    // ------------------------------------------------------------ main logic

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            retreating = false;
            return;
        }
        if (pause > 0) pause--;
        if (faceTicks > 0) faceTicks--;
        if (cooldown > 0) {
            cooldown--;
            retreating = false;
            return;
        }

        // stuck detection (pit, web, wall): we are retreating but not moving
        Vec3d pos = p.getPos();
        if (retreating && lastPos != null && pos.squaredDistanceTo(lastPos) < 0.0036) stuckTicks++;
        else stuckTicks = 0;
        lastPos = pos;

        List<LivingEntity> enemies = new ArrayList<>();
        List<LivingEntity> threats = new ArrayList<>();
        boolean combat = false;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;
            double dist = p.distanceTo(le);
            if (dist > 32) continue;
            if (le instanceof PlayerEntity pe) {
                if (pe.isSpectator()) continue;
                enemies.add(le);
                if (!AntiBot.isBot(pe)) {
                    if (dist <= combatRange.get()) combat = true;
                    if (dist <= retreatRange.get()) threats.add(le);
                }
            } else if (avoid.is("All Living")) {
                enemies.add(le);
                if (dist <= retreatRange.get()) threats.add(le);
            }
        }

        boolean needHeal = healthPots.get() && p.getHealth() <= healthAt.get();
        boolean needStr = strengthPots.get() && !p.hasStatusEffect(StatusEffects.STRENGTH) && (combat || !combatOnly.get());
        boolean needSpd = speedPots.get() && !p.hasStatusEffect(StatusEffects.SPEED) && (combat || !combatOnly.get());

        if (needHeal && tryThrow(HEAL, enemies)) { done(); return; }
        if (needStr && tryThrow(STRENGTH, enemies)) { done(); return; }
        if (needSpd && tryThrow(SPEED, enemies)) { done(); return; }

        boolean healReady = needHeal && findSlot(HEAL) >= 0;

        // nothing safe: if we are cornered / critical / waited long enough, throw anyway
        if (healReady) {
            noSafeTicks++;
            boolean web = CritUtil.inWeb(p);
            boolean critical = p.getHealth() <= panicHealth.get();
            if (panic.get() && (web || stuckTicks >= 8 || critical || noSafeTicks >= panicDelay.getInt())) {
                if (panicThrow(HEAL, enemies)) { done(); return; }
            }
            if (web) {
                retreating = false;   // running is pointless inside a web
                return;
            }
        } else {
            noSafeTicks = 0;
        }

        boolean potionWaiting = healReady
                || (retreatBuffs.get() && ((needStr && findSlot(STRENGTH) >= 0) || (needSpd && findSlot(SPEED) >= 0)));

        if (retreat.get() && pause == 0 && potionWaiting && !threats.isEmpty()) {
            double sx = 0.0, sz = 0.0;
            for (LivingEntity e : threats) {
                double dx = p.getX() - e.getX();
                double dz = p.getZ() - e.getZ();
                double d = Math.max(1.0, Math.hypot(dx, dz));
                sx += dx / d / d;
                sz += dz / d / d;
            }
            if (Math.abs(sx) + Math.abs(sz) > 1.0E-6) {
                retreatYaw = (float) (Math.toDegrees(Math.atan2(sz, sx)) - 90.0);
            }
            retreating = true;
            p.setSprinting(true);
            if (++retreatTicks > maxRetreat.getInt()) {
                stopRetreat();
                pause = 40;
            }
        } else {
            stopRetreat();
        }
    }

    private void done() {
        stopRetreat();
        noSafeTicks = 0;
        stuckTicks = 0;
    }

    private void stopRetreat() {
        retreating = false;
        retreatTicks = 0;
    }

    /** Smoothly turns the player's back to the enemies while retreating. */
    @Override
    public void onFrame() {
        long now = System.nanoTime();
        double dt = Math.min(2.0, (now - last) / 50_000_000.0);
        last = now;

        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;

        if (!retreating) {
            if (faceTicks > 0 && faceTarget != null && faceTarget.isAlive()) {
                float[] r = TargetUtil.rotations(faceTarget);
                double f = 1.0 - Math.pow(1.0 - 0.30, dt);
                float ny = p.getYaw() + (float) (MathHelper.wrapDegrees(r[0] - p.getYaw()) * f);
                float np = MathHelper.clamp(p.getPitch() + (float) ((r[1] - p.getPitch()) * f), -90f, 90f);
                p.setYaw(ny);
                p.setPitch(np);
                p.prevYaw = ny;
                p.prevPitch = np;
            }
            return;
        }

        float diff = MathHelper.wrapDegrees(retreatYaw - p.getYaw());
        double factor = 1.0 - Math.pow(1.0 - 0.35, dt);
        float ny = p.getYaw() + (float) (diff * factor);
        p.setYaw(ny);
        p.prevYaw = ny;
    }

    // ------------------------------------------------------------ throwing

    private float[] awayYaws(List<LivingEntity> enemies) {
        var p = mc.player;
        double sx = 0.0, sz = 0.0;
        for (LivingEntity e : enemies) {
            double dx = p.getX() - e.getX();
            double dz = p.getZ() - e.getZ();
            double d = Math.max(1.0, Math.hypot(dx, dz));
            sx += dx / d / d;
            sz += dz / d / d;
        }
        float baseYaw = p.getYaw();
        float awayYaw = (Math.abs(sx) + Math.abs(sz) > 1.0E-6)
                ? (float) (Math.toDegrees(Math.atan2(sz, sx)) - 90.0)
                : baseYaw;
        return new float[]{awayYaw, baseYaw, awayYaw + 40f, awayYaw - 40f};
    }

    private static final float[] PITCHES = {90f, 85f, 80f, 75f, 70f, 60f, 50f};

    /** Safe throw: the splash zone never touches an enemy hitbox. */
    private boolean tryThrow(int kind, List<LivingEntity> enemies) {
        var p = mc.player;
        int slot = findSlot(kind);
        if (slot < 0) return false;

        Vec3d pv = p.getVelocity();
        double bestDist = Double.MAX_VALUE;
        float bestYaw = 0f, bestPitch = 0f;
        boolean found = false;

        for (float yaw : awayYaws(enemies)) {
            for (float pitch : PITCHES) {
                Landing l = simulate(yaw, pitch, enemies);
                if (l == null || l.hitEntity()) continue;
                if (!safe(l, enemies)) continue;

                Vec3d self = p.getPos().add(pv.x * l.ticks(), 0, pv.z * l.ticks());
                double d = l.pos().distanceTo(self);
                if (d > maxSelf.get()) continue;
                double score = d - (lookDown.get() ? pitch / 90.0 * 0.4 : 0.0);
                if (score < bestDist) {
                    bestDist = score;
                    bestYaw = MathHelper.wrapDegrees(yaw);
                    bestPitch = pitch;
                    found = true;
                }
            }
        }

        if (!found) return false;
        throwPot(slot, bestYaw, bestPitch, enemies);
        return true;
    }

    /** Emergency throw: lands close to us and as far from the enemies as possible, even if they are near. */
    private boolean panicThrow(int kind, List<LivingEntity> enemies) {
        var p = mc.player;
        int slot = findSlot(kind);
        if (slot < 0) return false;

        Vec3d pv = p.getVelocity();
        double bestScore = -Double.MAX_VALUE;
        float bestYaw = p.getYaw(), bestPitch = 90f;

        for (float yaw : awayYaws(enemies)) {
            for (float pitch : PITCHES) {
                Landing l = simulate(yaw, pitch, enemies);
                if (l == null || l.hitEntity()) continue;
                Vec3d self = p.getPos().add(pv.x * l.ticks(), 0, pv.z * l.ticks());
                double selfD = l.pos().distanceTo(self);
                if (selfD > 3.5) continue;

                double minEnemy = 64.0;
                for (LivingEntity e : enemies) {
                    minEnemy = Math.min(minEnemy, l.pos().distanceTo(e.getBoundingBox().getCenter()));
                }
                double score = minEnemy - 1.5 * selfD;
                if (score > bestScore) {
                    bestScore = score;
                    bestYaw = MathHelper.wrapDegrees(yaw);
                    bestPitch = pitch;
                }
            }
        }

        throwPot(slot, bestYaw, bestPitch, enemies);
        return true;
    }

    /** Throws the potion; the head really looks down, then turns back to the enemy. */
    private void throwPot(int slot, float yaw, float pitch, List<LivingEntity> enemies) {
        ItemUtil.use(slot, yaw, pitch, true, !lookDown.get());
        cooldown = delay.getInt();
        if (faceEnemy.get()) {
            LivingEntity nearest = null;
            double nd = Double.MAX_VALUE;
            for (LivingEntity e : enemies) {
                double d = e.distanceTo(mc.player);
                if (d < nd) {
                    nd = d;
                    nearest = e;
                }
            }
            faceTarget = nearest;
            faceTicks = nearest == null ? 0 : 16;
        }
    }

    // ------------------------------------------------------------ potion physics

    /** Simulates a thrown splash potion (speed 0.5, roll -20, gravity 0.05, drag 0.99). */
    private Landing simulate(float yaw, float pitch, List<LivingEntity> enemies) {
        var p = mc.player;
        float yawR = yaw * 0.017453292f;
        float pitchR = pitch * 0.017453292f;
        double fx = -MathHelper.sin(yawR) * MathHelper.cos(pitchR);
        double fy = -MathHelper.sin((pitch - 20f) * 0.017453292f);
        double fz = MathHelper.cos(yawR) * MathHelper.cos(pitchR);

        Vec3d vel = new Vec3d(fx, fy, fz).normalize().multiply(0.5);
        Vec3d pv = p.getVelocity();
        vel = vel.add(pv.x, p.isOnGround() ? 0.0 : pv.y, pv.z);

        Vec3d pos = new Vec3d(p.getX(), p.getEyeY() - 0.1, p.getZ());
        for (int t = 0; t < 80; t++) {
            Vec3d next = pos.add(vel);

            for (LivingEntity e : enemies) {
                if (e.getBoundingBox().expand(0.3).contains(next)) {
                    return new Landing(next, t + 1, true);
                }
            }

            BlockHitResult hit = mc.world.raycast(new RaycastContext(pos, next,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            if (hit.getType() != HitResult.Type.MISS) {
                return new Landing(hit.getPos(), t + 1, false);
            }

            pos = next;
            vel = vel.multiply(0.99).subtract(0.0, 0.05, 0.0);
        }
        return null;
    }

    /** True if no enemy hitbox can be inside the splash zone (4 / 2 / 4 blocks around the impact point). */
    private boolean safe(Landing l, List<LivingEntity> enemies) {
        double m = margin.get();
        Box zone = new Box(l.pos(), l.pos()).expand(4.0 + m, 2.0 + m, 4.0 + m);
        for (LivingEntity e : enemies) {
            Box b = e.getBoundingBox();
            Vec3d v = e.getVelocity();
            Box moved = b.union(b.offset(new Vec3d(v.x * l.ticks(), 0.0, v.z * l.ticks())));
            if (zone.intersects(moved)) return false;
        }
        return true;
    }

    // ------------------------------------------------------------ inventory

    private int findSlot(int kind) {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(Items.SPLASH_POTION) && kindOf(s) == kind) return i;
        }
        return -1;
    }

    private static int kindOf(ItemStack stack) {
        PotionContentsComponent c = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (c == null) return 0;
        for (StatusEffectInstance ei : c.getEffects()) {
            if (ei.getEffectType().equals(StatusEffects.INSTANT_HEALTH)) return HEAL;
            if (ei.getEffectType().equals(StatusEffects.STRENGTH)) return STRENGTH;
            if (ei.getEffectType().equals(StatusEffects.SPEED)) return SPEED;
        }
        return 0;
    }
}
