package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.util.Render2D;
import com.hile.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;

import java.util.ArrayDeque;

public class Keystrokes extends Module {
    private final ArrayDeque<Long> left = new ArrayDeque<>();
    private final ArrayDeque<Long> right = new ArrayDeque<>();
    private boolean lastL, lastR;

    public Keystrokes() {
        super("Keystrokes", "WASD tuslari ve tik hizi (CPS).", Category.RENDER);
        group("Interface");
    }

    @Override public boolean showInList() { return false; }

    private static int cps(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
        return q.size();
    }

    private void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String label, boolean down) {
        int accent = Theme.accent(x);
        Render2D.round(ctx, x, y, w, h, 4, down ? Theme.alpha(accent, 200) : Theme.alpha(Theme.card(), 205));
        Render2D.ring(ctx, x, y, w, h, 4, Theme.alpha(accent, down ? 200 : 60));
        ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2, down ? 0xFFFFFFFF : Theme.text1(), false);
    }

    @Override
    public void onHud(DrawContext ctx) {
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        long now = System.currentTimeMillis();

        KeyBinding atk = mc.options.attackKey, use = mc.options.useKey;
        boolean l = atk.isPressed(), r = use.isPressed();
        if (l && !lastL) left.addLast(now);
        if (r && !lastR) right.addLast(now);
        lastL = l;
        lastR = r;

        int s = 20, g = 2;
        int x = 6, y = mc.getWindow().getScaledHeight() / 2 - 30;
        key(ctx, tr, x + s + g, y, s, s, "W", mc.options.forwardKey.isPressed());
        key(ctx, tr, x, y + s + g, s, s, "A", mc.options.leftKey.isPressed());
        key(ctx, tr, x + s + g, y + s + g, s, s, "S", mc.options.backKey.isPressed());
        key(ctx, tr, x + 2 * (s + g), y + s + g, s, s, "D", mc.options.rightKey.isPressed());
        int w2 = (3 * s + 2 * g - g) / 2;
        key(ctx, tr, x, y + 2 * (s + g), w2, s, "L " + cps(left, now), l);
        key(ctx, tr, x + w2 + g, y + 2 * (s + g), w2, s, "R " + cps(right, now), r);
    }
}
