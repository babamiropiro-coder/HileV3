package com.hile.module;

import com.hile.module.impl.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void init() {
        // client
        MODULES.add(new Interface());
        MODULES.add(new HitSounds());
        MODULES.add(new Notifications());
        // combat
        MODULES.add(new KillAura());
        MODULES.add(new AimAssist());
        MODULES.add(new TriggerBot());
        MODULES.add(new AutoPot());
        MODULES.add(new AutoTotem());
        MODULES.add(new Velocity());
        MODULES.add(new AntiBot());
        // movement
        MODULES.add(new Sprint());
        MODULES.add(new ElytraTarget());
        MODULES.add(new SafeWalk());
        MODULES.add(new AutoTool());
        MODULES.add(new AutoRespawn());
        // visuals
        MODULES.add(new Hud());
        MODULES.add(new TargetHud());
        MODULES.add(new ArmorHud());
        MODULES.add(new PotionHud());
        MODULES.add(new Keystrokes());
        MODULES.add(new Coordinates());
        MODULES.add(new Esp());
        MODULES.add(new Tracers());
        MODULES.add(new JumpCircle());
        MODULES.add(new Fullbright());
        MODULES.add(new TimeChanger());
        MODULES.add(new Zoom());
        // cosmetics
        MODULES.add(new Cape());
        MODULES.add(new Hat());
        MODULES.add(new Back());

        for (Class<? extends Module> c : List.<Class<? extends Module>>of(
                Interface.class, Hud.class, AntiBot.class, Notifications.class,
                TargetHud.class, PotionHud.class, ArmorHud.class)) {
            get(c).setEnabled(true, false);
        }
    }

    public static List<Module> getModules() { return Collections.unmodifiableList(MODULES); }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.getCategory() == c) out.add(m);
        return out;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return (T) m;
        return null;
    }

    public static void tick() {
        for (Module m : MODULES) if (m.isEnabled()) m.onTick();
    }

    public static void frame() {
        for (Module m : MODULES) if (m.isEnabled()) m.onFrame();
    }

    public static void hud(DrawContext ctx) {
        for (Module m : MODULES) if (m.isEnabled()) m.onHud(ctx);
    }

    public static void render3d(WorldRenderContext ctx) {
        for (Module m : MODULES) if (m.isEnabled()) m.onRender3D(ctx);
    }
}
