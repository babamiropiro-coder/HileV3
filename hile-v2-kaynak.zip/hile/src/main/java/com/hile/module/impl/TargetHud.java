package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.BoolSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.ColorUtil;
import com.hile.util.CombatState;
import com.hile.util.Render2D;
import com.hile.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;

public class TargetHud extends Module {
    private final NumberSetting showFor = add(new NumberSetting("Show For (s)", 4, 1, 10, 1));
    private final BoolSetting armor = add(new BoolSetting("Armor", true));
    private final NumberSetting offsetY = add(new NumberSetting("Offset Y", 36, -80, 120, 2));

    private LivingEntity shownFor;
    private float shownHealth;

    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public TargetHud() {
        super("TargetHUD", "Vurdugun hedefin cani, zirhi ve kafasi.", Category.RENDER);
        group("Interface");
    }

    @Override public boolean showInList() { return false; }

    @Override
    public void onHud(DrawContext ctx) {
        if (mc.player == null || mc.options.hudHidden) return;
        LivingEntity t = CombatState.current(showFor.getInt() * 1000L);
        if (t == null || (!t.isAlive() && t.getHealth() <= 0f && shownHealth < 0.1f)) return;
        if (t != shownFor) {
            shownFor = t;
            shownHealth = t.getHealth();
        }
        shownHealth += (t.getHealth() - shownHealth) * 0.12f;

        TextRenderer tr = mc.textRenderer;
        int w = 150, h = armor.get() ? 50 : 40;
        int x = mc.getWindow().getScaledWidth() / 2 + 28;
        int y = mc.getWindow().getScaledHeight() / 2 + offsetY.getInt();
        int accent = Theme.accent(0);

        Render2D.round(ctx, x, y, w, h, 7, Theme.alpha(Theme.card(), 230));
        Render2D.ring(ctx, x, y, w, h, 7, Theme.alpha(accent, 80));

        // head
        if (t instanceof AbstractClientPlayerEntity ap) {
            var tex = ap.getSkinTextures().texture();
            ctx.drawTexture(tex, x + 6, y + 6, 28, 28, 8f, 8f, 8, 8, 64, 64);
            ctx.drawTexture(tex, x + 6, y + 6, 28, 28, 40f, 8f, 8, 8, 64, 64);
        } else {
            Render2D.round(ctx, x + 6, y + 6, 28, 28, 6, Theme.alpha(accent, 60));
            Render2D.logo(ctx, x + 10, y + 10, 20, 0.9f);
        }

        String name = t.getName().getString();
        if (name.length() > 16) name = name.substring(0, 16);
        ctx.drawText(tr, name, x + 40, y + 7, Theme.text1(), false);

        float max = Math.max(1f, t.getMaxHealth());
        float pct = MathHelper.clamp(shownHealth / max, 0f, 1f);
        int bx = x + 40, by = y + 19, bw = w - 48;
        Render2D.round(ctx, bx, by, bw, 6, 3, Theme.alpha(Theme.field(), 255));
        int fw = Math.max(4, (int) (bw * pct));
        int hp = ColorUtil.mix(0xFFF87171, 0xFF4ADE80, pct);
        Render2D.round(ctx, bx, by, fw, 6, 3, hp);

        String hpText = String.format(Locale.ROOT, "%.1f", Math.max(0f, t.getHealth()));
        ctx.drawText(tr, hpText, x + w - 8 - tr.getWidth(hpText), y + 7, Theme.accentLight(0), false);

        if (armor.get()) {
            var m = ctx.getMatrices();
            for (int i = 0; i < SLOTS.length; i++) {
                ItemStack st = t.getEquippedStack(SLOTS[i]);
                if (st.isEmpty()) continue;
                m.push();
                m.translate(x + 40 + i * 14, y + 29, 0f);
                m.scale(0.75f, 0.75f, 1f);
                ctx.drawItem(st, 0, 0);
                m.pop();
            }
            ItemStack main = t.getMainHandStack();
            if (!main.isEmpty()) {
                m.push();
                m.translate(x + 40 + 4 * 14 + 6, y + 29, 0f);
                m.scale(0.75f, 0.75f, 1f);
                ctx.drawItem(main, 0, 0);
                m.pop();
            }
        }
    }
}
