package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;

public class Velocity extends Module {
    private final NumberSetting horizontal = add(new NumberSetting("Horizontal %", 60, 0, 100, 5));
    private final NumberSetting vertical = add(new NumberSetting("Vertical %", 100, 0, 100, 5));

    public Velocity() {
        super("Velocity", "Vurulunca gelen geri tepmeyi azaltir.", Category.COMBAT);
        group("Support");
    }

    public static boolean active() {
        Velocity v = ModuleManager.get(Velocity.class);
        return v != null && v.isEnabled();
    }

    public static void handle(ClientPlayerEntity p, EntityVelocityUpdateS2CPacket packet) {
        Velocity v = ModuleManager.get(Velocity.class);
        if (v == null) return;
        double h = v.horizontal.get() / 100.0, y = v.vertical.get() / 100.0;
        p.setVelocity(packet.getVelocityX() * h, packet.getVelocityY() * y, packet.getVelocityZ() * h);
    }
}
