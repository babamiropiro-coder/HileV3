package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import net.minecraft.util.Identifier;

import java.util.Locale;

public class Cape extends Module {
    private static final int FRAMES = 12;

    private final ModeSetting style = add(new ModeSetting("Style", "Zeno", "Violet", "Crimson", "Emerald", "Shadow"));
    private final BoolSetting animated = add(new BoolSetting("Animated", true));
    private final NumberSetting speed = add(new NumberSetting("Frame Time (ms)", 90, 40, 250, 10));
    private final BoolSetting elytra = add(new BoolSetting("Matching Elytra", true));

    public Cape() {
        super("Cape", "Zeno logolu, animasyonlu pelerin ve uyumlu elytra.", Category.COSMETICS);
    }

    private int frame() {
        if (!animated.get()) return 0;
        return (int) ((System.currentTimeMillis() / speed.getInt()) % FRAMES);
    }

    private String slug() { return style.get().toLowerCase(Locale.ROOT); }

    /** Current cape texture, or null when disabled. */
    public static Identifier texture() {
        Cape c = ModuleManager.get(Cape.class);
        if (c == null || !c.isEnabled()) return null;
        return Identifier.of("hile", "textures/cape/" + c.slug() + "_" + c.frame() + ".png");
    }

    /** Matching elytra texture (fixes the garbled elytra with a custom cape), or null. */
    public static Identifier elytraTexture() {
        Cape c = ModuleManager.get(Cape.class);
        if (c == null || !c.isEnabled() || !c.elytra.get()) return null;
        return Identifier.of("hile", "textures/elytra/" + c.slug() + "_" + c.frame() + ".png");
    }
}
