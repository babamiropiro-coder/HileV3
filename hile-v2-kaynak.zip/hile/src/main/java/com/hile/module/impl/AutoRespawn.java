package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;

public class AutoRespawn extends Module {
    public AutoRespawn() {
        super("AutoRespawn", "Olunce otomatik yeniden dogar.", Category.MOVEMENT);
        group("Utility");
    }

    @Override
    public void onTick() {
        if (mc.player != null && mc.player.isDead()) mc.player.requestRespawn();
    }
}
