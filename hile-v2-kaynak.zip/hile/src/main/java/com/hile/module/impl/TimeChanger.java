package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.NumberSetting;

public class TimeChanger extends Module {
    private final NumberSetting time = add(new NumberSetting("Time", 6000, 0, 24000, 500));

    public TimeChanger() {
        super("TimeChanger", "Oyun saatini sadece senin ekraninda degistirir (6000 gunduz, 18000 gece).", Category.RENDER);
        group("World");
    }

    @Override
    public void onTick() {
        if (mc.world != null) mc.world.setTimeOfDay(time.getInt());
    }
}
