package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.NumberSetting;

public class Zoom extends Module {
    private final NumberSetting fov = add(new NumberSetting("Zoom FOV", 30, 30, 90, 1));
    private int old = -1;

    public Zoom() {
        super("Zoom", "Acinca gorus acisini daraltir (yakinlastirir).", Category.RENDER);
        group("World");
    }

    @Override
    protected void onEnable() {
        old = mc.options.getFov().getValue();
    }

    @Override
    protected void onDisable() {
        if (old > 0) mc.options.getFov().setValue(old);
        old = -1;
    }

    @Override
    public void onTick() {
        mc.options.getFov().setValue(fov.getInt());
    }
}
