package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.CritUtil;
import com.hile.util.SoundFx;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public class HitSounds extends Module {
    private static final Map<String, String> SOUNDS = new LinkedHashMap<>();
    private static final Set<String> VANILLA = Set.of(
            "entity.player.attack.strong", "entity.player.attack.weak", "entity.player.attack.crit",
            "entity.player.attack.knockback", "entity.player.attack.sweep", "entity.player.attack.nodamage");
    static {
        SOUNDS.put("Orb", "entity.experience_orb.pickup");
        SOUNDS.put("Bell", "block.note_block.bell");
        SOUNDS.put("Pling", "block.note_block.pling");
        SOUNDS.put("Bonk", "block.note_block.basedrum");
        SOUNDS.put("Anvil", "block.anvil.land");
        SOUNDS.put("Crit", "entity.player.attack.crit");
        SOUNDS.put("Chime", "block.amethyst_block.chime");
        SOUNDS.put("Click", "ui.button.click");
        SOUNDS.put("Arrow", "entity.arrow.hit_player");
        SOUNDS.put("Bit", "block.note_block.bit");
        SOUNDS.put("Xylophone", "block.note_block.xylophone");
        SOUNDS.put("Level Up", "entity.player.levelup");
    }

    private static volatile boolean playing;

    private static String[] withOff(String first) {
        String[] out = new String[SOUNDS.size() + 1];
        out[0] = first;
        int i = 1;
        for (String k : SOUNDS.keySet()) out[i++] = k;
        return out;
    }

    private final ModeSetting playerSound = add(new ModeSetting("Player Hit", withOff("Off")));
    private final ModeSetting mobSound = add(new ModeSetting("Mob Hit", withOff("Off")));
    private final ModeSetting critSound = add(new ModeSetting("Crit Hit", withOff("Same As Hit")));
    private final ModeSetting killSound = add(new ModeSetting("Kill Sound", withOff("Off")));
    private final BoolSetting muteVanilla = add(new BoolSetting("Mute Vanilla Hit Sounds", true));
    private final NumberSetting volume = add(new NumberSetting("Volume", 1.0, 0.1, 2.0, 0.1));
    private final NumberSetting pitch = add(new NumberSetting("Pitch", 1.0, 0.5, 2.0, 0.1));
    private final BoolSetting streak = add(new BoolSetting("Kill Streak Pitch", true));
    private final BoolSetting randomPitch = add(new BoolSetting("Random Pitch", true));

    private LivingEntity pending;
    private boolean pendingCrit;
    private boolean pendingPlayer;
    private float pendingHealth;
    private int pendingAge;

    private int streakCount;
    private long lastKill;
    private LivingEntity lastTarget;
    private int age;

    public HitSounds() {
        super("HitSounds", "Gercek vurusta, critical vurusta ve oldurmede ses cikarir.", Category.CLIENT);
        group("Sounds");
        playerSound.cycle(1);
        mobSound.cycle(1);
    }

    private void play(String mode) { play(mode, 1f); }

    private void play(String mode, float boost) {
        String id = SOUNDS.get(mode);
        if (id == null) return;
        float pt = pitch.getFloat() * boost;
        if (randomPitch.get()) pt *= 0.92f + ThreadLocalRandom.current().nextFloat() * 0.16f;
        playing = true;
        try {
            SoundFx.play(id, pt, volume.getFloat());
        } finally {
            playing = false;
        }
    }

    /** Called right before an attack is sent. The sound is only played once the hit really lands. */
    public static void onAttack(Entity target) {
        HitSounds h = ModuleManager.get(HitSounds.class);
        if (h == null || !h.isEnabled() || !(target instanceof LivingEntity le)) return;
        var p = h.mc.player;
        if (p == null) return;

        h.pending = le;
        h.pendingHealth = le.getHealth();
        h.pendingPlayer = target instanceof PlayerEntity;
        h.pendingAge = 0;
        h.pendingCrit = p.getAttackCooldownProgress(0.5f) > 0.9f && CritUtil.canCrit(p) && !p.isSprinting();
        h.lastTarget = le;
        h.age = 0;
    }

    /** Used by the sound mixin to hide the vanilla attack sounds. */
    public static boolean shouldMute(SoundInstance sound) {
        if (playing) return false;
        HitSounds h = ModuleManager.get(HitSounds.class);
        if (h == null || !h.isEnabled() || !h.muteVanilla.get()) return false;
        return VANILLA.contains(sound.getId().getPath());
    }

    @Override
    public void onTick() {
        if (pending != null) {
            boolean landed = pending.hurtTime > 0 || pending.getHealth() < pendingHealth || pending.isDead();
            if (landed) {
                String mode = pendingPlayer ? playerSound.get() : mobSound.get();
                if (pendingCrit && !critSound.is("Same As Hit")) mode = critSound.get();
                play(mode);
                pending = null;
            } else if (++pendingAge > 4) {
                pending = null;   // it did not land (cooldown, invulnerability frames, miss) -> no sound
            }
        }

        if (lastTarget != null) {
            if (lastTarget.isDead() || lastTarget.getHealth() <= 0f) {
                long now = System.currentTimeMillis();
                streakCount = now - lastKill < 6000 ? Math.min(streakCount + 1, 8) : 0;
                lastKill = now;
                play(killSound.get(), streak.get() ? 1f + 0.08f * streakCount : 1f);
                lastTarget = null;
            } else if (++age > 60) {
                lastTarget = null;
            }
        }
    }
}
