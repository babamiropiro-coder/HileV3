package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.NumberSetting;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final NumberSetting delay = add(new NumberSetting("Delay (ticks)", 4, 1, 20, 1));
    private final NumberSetting health = add(new NumberSetting("Only Below HP", 20, 2, 20, 1));

    private int cd;

    public AutoTotem() {
        super("AutoTotem", "Elindeki totem bitince envanterden yenisini koyar.", Category.COMBAT);
        group("Support");
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cd > 0) {
            cd--;
            return;
        }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (p.getHealth() > health.get()) return;

        int slot = -1;
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                slot = i;
                break;
            }
        }
        if (slot < 0) return;
        // inventory index -> container slot id (hotbar 0-8 -> 36-44, main 9-35 -> 9-35)
        int container = slot < 9 ? slot + 36 : slot;
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, container, 40, SlotActionType.SWAP, p);
        cd = delay.getInt();
    }
}
