package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.AntiBotHelper;
import com.hile.util.Theme;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class Esp extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Glow", "Box"));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile Mobs", false));
    private final BoolSetting passive = add(new BoolSetting("Passive Mobs", false));
    private final NumberSetting range = add(new NumberSetting("Range", 64, 16, 128, 4));

    private final List<Entity> glowing = new ArrayList<>();

    public Esp() {
        super("ESP", "Oyunculari duvarin arkasindan bile gosterir (Glow) veya kutu cizer (Box).", Category.RENDER);
        group("World");
    }

    private boolean valid(Entity e) {
        var p = mc.player;
        if (p == null || e == p || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity || !e.isAlive()) return false;
        if (p.distanceTo(e) > range.get()) return false;
        if (e instanceof PlayerEntity pe) return players.get() && !pe.isSpectator() && !AntiBotHelper.isBot(pe);
        if (e instanceof Monster) return hostile.get();
        return passive.get();
    }

    private void clearGlow() {
        for (Entity e : glowing) e.setGlowing(false);
        glowing.clear();
    }

    @Override protected void onDisable() { clearGlow(); }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        clearGlow();
        if (!mode.is("Glow")) return;
        for (Entity e : mc.world.getEntities()) {
            if (valid(e)) {
                e.setGlowing(true);
                glowing.add(e);
            }
        }
    }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        if (!mode.is("Box") || mc.world == null || mc.player == null) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider consumers = ctx.consumers();
        if (ms == null || consumers == null) return;

        float td = mc.getRenderTickCounter().getTickDelta(true);
        Vec3d cam = ctx.camera().getPos();
        int col = Theme.accent(0);
        float r = ((col >> 16) & 255) / 255f, g = ((col >> 8) & 255) / 255f, b = (col & 255) / 255f;

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        for (Entity e : mc.world.getEntities()) {
            if (!valid(e)) continue;
            Vec3d d = e.getLerpedPos(td).subtract(e.getPos());
            Box box = e.getBoundingBox().offset(d);
            WorldRenderer.drawBox(ms, vc, box, r, g, b, 1.0f);
        }
        ms.pop();
        if (consumers instanceof VertexConsumerProvider.Immediate im) im.draw(RenderLayer.getLines());
    }
}
