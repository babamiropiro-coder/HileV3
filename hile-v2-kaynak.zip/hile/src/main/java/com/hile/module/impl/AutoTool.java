package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public class AutoTool extends Module {
    public AutoTool() {
        super("AutoTool", "Kazarken en hizli aleti otomatik secer.", Category.MOVEMENT);
        group("Utility");
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        BlockState state = mc.world.getBlockState(hit.getBlockPos());
        float best = 1.0f;
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            float sp = p.getInventory().getStack(i).getMiningSpeedMultiplier(state);
            if (sp > best) {
                best = sp;
                slot = i;
            }
        }
        if (slot >= 0 && slot != p.getInventory().selectedSlot) p.getInventory().selectedSlot = slot;
    }
}
