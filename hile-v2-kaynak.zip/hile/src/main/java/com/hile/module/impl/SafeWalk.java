package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;

public class SafeWalk extends Module {
    public SafeWalk() {
        super("SafeWalk", "Blok kenarindan dusmezsin (egilmeden).", Category.MOVEMENT);
    }

    public static boolean active() {
        SafeWalk s = ModuleManager.get(SafeWalk.class);
        return s != null && s.isEnabled();
    }
}
