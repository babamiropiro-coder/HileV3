package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.BoolSetting;
import com.hile.setting.ColorSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.ColorUtil;
import com.hile.util.Theme;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public class JumpCircle extends Module {
    private final NumberSetting size = add(new NumberSetting("Size", 2.0, 0.5, 5.0, 0.1));
    private final NumberSetting duration = add(new NumberSetting("Duration (ms)", 900, 300, 2500, 50));
    private final NumberSetting thickness = add(new NumberSetting("Thickness", 0.14, 0.03, 0.6, 0.01));
    private final ModeSetting style = add(new ModeSetting("Style", "Ring", "Filled", "Double"));
    private final ModeSetting colorMode = add(new ModeSetting("Color", "Theme", "Rainbow", "Custom"));
    private final ColorSetting custom = add(new ColorSetting("Custom Color", 0x3B82F6));
    private final BoolSetting onLand = add(new BoolSetting("On Landing", false));

    private record Ring(Vec3d pos, long born) {}

    private final List<Ring> rings = new ArrayList<>();
    private boolean wasGround = true;

    public JumpCircle() {
        super("JumpCircle", "Zipladigin yerde genisleyen parlak halka.", Category.RENDER);
        group("World");
    }

    private void addRing(Vec3d pos) {
        rings.add(0, new Ring(pos, System.currentTimeMillis()));
        while (rings.size() > 8) rings.remove(rings.size() - 1);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        boolean ground = p.isOnGround();
        if (wasGround && !ground && p.getVelocity().y > 0.1) addRing(p.getPos());
        if (onLand.get() && !wasGround && ground) addRing(p.getPos());
        wasGround = ground;
    }

    private int baseColor(float phase) {
        switch (colorMode.get()) {
            case "Rainbow": return ColorUtil.mix(0xFF000000 | ColorUtil.fromHsv(phase, 0.6f, 1f), 0xFFFFFFFF, 0.1f);
            case "Custom":  return 0xFF000000 | custom.get();
            default:        return Theme.accent(phase * 360f);
        }
    }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        if (rings.isEmpty()) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider consumers = ctx.consumers();
        if (ms == null || consumers == null) return;

        Vec3d cam = ctx.camera().getPos();
        long now = System.currentTimeMillis();
        long life = duration.getInt();

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = ms.peek().getPositionMatrix();
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getDebugQuads());

        for (int i = rings.size() - 1; i >= 0; i--) {
            Ring ring = rings.get(i);
            float t = (now - ring.born()) / (float) life;
            if (t >= 1f) {
                rings.remove(i);
                continue;
            }
            float ease = 1f - (1f - t) * (1f - t) * (1f - t);
            float radius = size.getFloat() * ease;
            float fade = 1f - t * t;
            int col = baseColor(t);
            int r = (col >> 16) & 255, g = (col >> 8) & 255, b = col & 255;

            drawRing(vc, m, ring.pos(), radius, thickness.getFloat() * (0.6f + 0.4f * fade), r, g, b, (int) (220 * fade),
                    style.is("Filled"));
            if (style.is("Double")) {
                drawRing(vc, m, ring.pos(), radius * 0.6f, thickness.getFloat() * 0.7f, r, g, b, (int) (150 * fade), false);
            }
        }
        ms.pop();
        if (consumers instanceof VertexConsumerProvider.Immediate im) im.draw(RenderLayer.getDebugQuads());
    }

    private static void drawRing(VertexConsumer vc, Matrix4f m, Vec3d c, float outer, float width, int r, int g, int b, int a,
                                 boolean filled) {
        if (a <= 2 || outer <= 0.02f) return;
        float inner = filled ? 0f : Math.max(0f, outer - width);
        float y = (float) c.y + 0.02f;
        int seg = 48;
        for (int i = 0; i < seg; i++) {
            double a0 = Math.PI * 2 * i / seg, a1 = Math.PI * 2 * (i + 1) / seg;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float cx = (float) c.x, cz = (float) c.z;
            vc.vertex(m, cx + c0 * inner, y, cz + s0 * inner).color(r, g, b, a);
            vc.vertex(m, cx + c0 * outer, y, cz + s0 * outer).color(r, g, b, a);
            vc.vertex(m, cx + c1 * outer, y, cz + s1 * outer).color(r, g, b, a);
            vc.vertex(m, cx + c1 * inner, y, cz + s1 * inner).color(r, g, b, a);
        }
    }
}
