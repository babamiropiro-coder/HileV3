package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.BoolSetting;
import com.hile.util.Render2D;
import com.hile.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Hud extends Module {
    private final BoolSetting watermark = add(new BoolSetting("Watermark", true));
    private final BoolSetting fps = add(new BoolSetting("FPS", true));
    private final BoolSetting ping = add(new BoolSetting("Ping", true));
    private final BoolSetting server = add(new BoolSetting("Server", true));
    private final BoolSetting clock = add(new BoolSetting("Clock", false));
    private final BoolSetting list = add(new BoolSetting("Module List", true));

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    public Hud() {
        super("HUD", "Sol ustte logo ve bilgi, sagda acik moduller.", Category.RENDER);
        group("Interface");
    }

    @Override public boolean showInList() { return false; }

    @Override
    public void onHud(DrawContext ctx) {
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;

        if (watermark.get()) {
            List<String> parts = new ArrayList<>();
            if (fps.get()) parts.add(mc.getCurrentFps() + " fps");
            if (ping.get()) {
                int ms = 0;
                if (mc.getNetworkHandler() != null) {
                    PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                    if (e != null) ms = e.getLatency();
                }
                parts.add(ms + " ms");
            }
            if (server.get()) {
                ServerInfo si = mc.getCurrentServerEntry();
                String addr = si == null ? "Singleplayer" : si.address;
                if (addr.length() > 20) addr = addr.substring(0, 20);
                parts.add(addr);
            }
            if (clock.get()) parts.add(LocalTime.now().format(TIME));

            int w = 22;
            for (String s : parts) w += tr.getWidth(s) + 12;
            w = Math.max(w, 24);
            int x = 6, y = 6;
            Render2D.round(ctx, x, y, w, 20, 6, Theme.alpha(Theme.card(), 225));
            Render2D.ring(ctx, x, y, w, 20, 6, Theme.alpha(Theme.accent(0), 70));
            Render2D.glow(ctx, x + 11, y + 10, 34, Theme.accent(0) & 0xFFFFFF, 0.5f);
            Render2D.logo(ctx, x + 3, y + 2, 16, 1f);
            int tx = x + 24;
            for (int i = 0; i < parts.size(); i++) {
                ctx.drawText(tr, parts.get(i), tx, y + 6, Theme.text1(), false);
                tx += tr.getWidth(parts.get(i));
                if (i < parts.size() - 1) {
                    Render2D.round(ctx, tx + 5, y + 8, 3, 3, 1, Theme.alpha(Theme.accent(i * 20), 200));
                    tx += 12;
                }
            }
        }

        if (list.get()) {
            List<Module> shown = new ArrayList<>();
            for (Module m : ModuleManager.getModules()) if (m.isEnabled() && m.showInList()) shown.add(m);
            shown.sort(Comparator.comparingInt((Module m) -> tr.getWidth(m.getName())).reversed());

            int right = mc.getWindow().getScaledWidth() - 5;
            int y = 5;
            int idx = 0;
            for (Module m : shown) {
                int w = tr.getWidth(m.getName()) + 12;
                int col = Theme.accent(idx * 18);
                Render2D.round(ctx, right - w, y, w, 12, 4, Theme.alpha(Theme.card(), 200));
                Render2D.round(ctx, right - 3, y + 2, 2, 8, 1, col);
                ctx.drawText(tr, m.getName(), right - w + 4, y + 2, Theme.accentLight(idx * 18), false);
                y += 14;
                idx++;
            }
        }
    }
}
