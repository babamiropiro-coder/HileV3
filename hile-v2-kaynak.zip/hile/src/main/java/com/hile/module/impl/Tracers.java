package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.NumberSetting;
import com.hile.util.AntiBotHelper;
import com.hile.util.Theme;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class Tracers extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 64, 16, 128, 4));

    public Tracers() {
        super("Tracers", "Oyunculara dogru cizgi cizer.", Category.RENDER);
        group("World");
    }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        if (mc.world == null || mc.player == null) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider consumers = ctx.consumers();
        if (ms == null || consumers == null) return;

        float td = mc.getRenderTickCounter().getTickDelta(true);
        Vec3d cam = ctx.camera().getPos();
        Vec3d look = Vec3d.fromPolar(mc.player.getPitch(td), mc.player.getYaw(td));
        Vec3d start = cam.add(look.multiply(0.5));

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        MatrixStack.Entry entry = ms.peek();
        Matrix4f m = entry.getPositionMatrix();
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        int col = Theme.accent(0);
        int r = (col >> 16) & 255, g = (col >> 8) & 255, b = col & 255;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity pe) || e == mc.player || pe.isSpectator() || !e.isAlive()) continue;
            if (mc.player.distanceTo(e) > range.get() || AntiBotHelper.isBot(pe)) continue;
            Vec3d end = e.getLerpedPos(td).add(0, e.getHeight() * 0.5, 0);
            Vec3d dir = end.subtract(start).normalize();
            vc.vertex(m, (float) start.x, (float) start.y, (float) start.z).color(r, g, b, 220)
                    .normal(entry, (float) dir.x, (float) dir.y, (float) dir.z);
            vc.vertex(m, (float) end.x, (float) end.y, (float) end.z).color(r, g, b, 220)
                    .normal(entry, (float) dir.x, (float) dir.y, (float) dir.z);
        }
        ms.pop();
        if (consumers instanceof VertexConsumerProvider.Immediate im) im.draw(RenderLayer.getLines());
    }
}
