package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.BoolSetting;
import com.hile.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

public class AntiBot extends Module {
    private final BoolSetting tab = add(new BoolSetting("Tab List Check", true));
    private final BoolSetting name = add(new BoolSetting("Name Check", true));
    private final BoolSetting uuid = add(new BoolSetting("UUID v4 Check", false));
    private final NumberSetting minAge = add(new NumberSetting("Min Age (ticks)", 10, 0, 100, 1));

    public AntiBot() {
        super("AntiBot", "Sahte oyuncu (bot/NPC) hedeflerini eler.", Category.COMBAT);
        group("Support");
    }

    public static boolean isBot(PlayerEntity pe) {
        AntiBot a = ModuleManager.get(AntiBot.class);
        if (a == null || !a.isEnabled()) return false;

        if (a.tab.get()) {
            var net = MinecraftClient.getInstance().getNetworkHandler();
            if (net == null || net.getPlayerListEntry(pe.getUuid()) == null) return true;
        }
        if (a.name.get()) {
            String n = pe.getName().getString();
            if (n == null || !n.matches("\\w{3,16}")) return true;
        }
        if (a.uuid.get() && pe.getUuid().version() != 4) return true;
        return pe.age < a.minAge.getInt();
    }
}
