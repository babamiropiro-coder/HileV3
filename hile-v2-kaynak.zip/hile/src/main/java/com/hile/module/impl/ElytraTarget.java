package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.BoolSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.ItemUtil;
import com.hile.util.TargetUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class ElytraTarget extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 60, 10, 120, 5));
    private final NumberSetting speed = add(new NumberSetting("Turn Speed", 35, 5, 100, 1));
    private final NumberSetting predict = add(new NumberSetting("Prediction", 3, 0, 10, 1));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile Mobs", false));
    private final BoolSetting rocket = add(new BoolSetting("Auto Rocket", true));
    private final NumberSetting minSpeed = add(new NumberSetting("Rocket Below Speed", 1.2, 0.5, 3.0, 0.1));
    private final NumberSetting rocketDelay = add(new NumberSetting("Rocket Delay", 25, 10, 80, 1));

    private LivingEntity target;
    private int rocketCd;
    private long last = System.nanoTime();

    public ElytraTarget() {
        super("ElytraTarget", "Elytra ile ucarken hedefe dogru yonelir.", Category.MOVEMENT);
        group("Elytra");
    }

    @Override
    protected void onDisable() { target = null; }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || !p.isFallFlying()) {
            target = null;
            return;
        }
        if (rocketCd > 0) rocketCd--;

        target = TargetUtil.find(range.get(), players.get(), hostile.get(), false, false, true, "Distance", 360.0);
        if (target == null || !rocket.get() || rocketCd > 0 || mc.currentScreen != null) return;

        if (p.getVelocity().length() < minSpeed.get()) {
            for (int i = 0; i < 9; i++) {
                if (p.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                    ItemUtil.use(i, 0f, 0f, false);
                    rocketCd = rocketDelay.getInt();
                    break;
                }
            }
        }
    }

    @Override
    public void onFrame() {
        long now = System.nanoTime();
        double dt = Math.min(2.0, (now - last) / 50_000_000.0);
        last = now;

        var p = mc.player;
        if (p == null || target == null || !target.isAlive() || !p.isFallFlying() || mc.currentScreen != null) return;

        Vec3d aim = new Vec3d(target.getX(), target.getY() + target.getHeight() * 0.5, target.getZ())
                .add(target.getVelocity().multiply(predict.get()));
        float[] r = TargetUtil.rotationsTo(aim);

        float yawDiff = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float pitchDiff = r[1] - p.getPitch();
        double factor = 1.0 - Math.pow(1.0 - speed.get() / 100.0, dt);

        float ny = p.getYaw() + (float) (yawDiff * factor);
        float np = MathHelper.clamp(p.getPitch() + (float) (pitchDiff * factor), -90f, 90f);
        p.setYaw(ny);
        p.setPitch(np);
        p.prevYaw = ny;
        p.prevPitch = np;
    }
}
